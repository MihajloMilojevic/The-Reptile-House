"use strict";
exports.id = 8345;
exports.ids = [8345];
exports.modules = {

/***/ 5009:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(7063);
async function sveSlike() {
    let data = await mysql.query("SELECT * FROM slike ORDER BY kategorija_id");
    await mysql.end();
    return data;
}
async function slikePoKategoriji(kategorija) {
    let data = await mysql.query("SELECT s.id, s.src FROM slike s JOIN kategorije k ON s.kategorija_id = k.id WHERE k.naziv = ?", [
        kategorija
    ]);
    await mysql.end();
    return data;
}
function spojiSlike(id_proizvoda, slike_id) {
    const params = [];
    let sql = "";
    slike_id.forEach((id_slike)=>{
        sql += "INSERT INTO proizvodi_slike(proizvod_id, slika_id) VALUES (?, ?); ";
        params.push(id_proizvoda);
        params.push(id_slike);
    });
    return [
        sql,
        params
    ];
}
module.exports = {
    sveSlike,
    slikePoKategoriji,
    spojiSlike
};


/***/ }),

/***/ 7063:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(2261)({
    config: {
        host: process.env.MYSQL_HOST,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD,
        multipleStatements: true
    }
});
module.exports = mysql;


/***/ }),

/***/ 4949:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const jwt = __webpack_require__(9344);
const { UnauthenticatedError  } = __webpack_require__(9367);
const auth = async (req, res)=>{
    const token = req.cookies.token;
    if (!token) throw new UnauthenticatedError("Authentication error");
    try {
        const sadrzaj = jwt.verify(token, process.env.JWT_SECRET) // VERIFY TOKEN
        ;
        return sadrzaj;
    } catch (error) {
        throw new UnauthenticatedError("Authentication error");
    }
};
module.exports = auth;


/***/ })

};
;