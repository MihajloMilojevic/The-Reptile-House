"use strict";
exports.id = 5217;
exports.ids = [5217];
exports.modules = {

/***/ 5217:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(7063);
const { hash  } = __webpack_require__(248);
async function pronadjiKorisnikaPoMejlu(mejl) {
    const data = await mysql.query("SELECT * FROM korisnici WHERE mejl = ?", [
        mejl
    ]);
    await mysql.end();
    if (!data || !data.length) return null;
    return data[0];
}
async function promeniLozinku(mejl, lozinka) {
    const hashed = await hash(lozinka);
    const data = await mysql.query("UPDATE korisnici SET lozinka = ? WHERE mejl = ?", [
        hashed,
        mejl
    ]);
    await mysql.end();
    return data;
}
module.exports = {
    pronadjiKorisnikaPoMejlu,
    promeniLozinku
};


/***/ }),

/***/ 7063:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(2261)({
    config: {
        host: process.env.MYSQL_HOST,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD,
        multipleStatements: true
    }
});
module.exports = mysql;


/***/ }),

/***/ 248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hash": () => (/* binding */ hash),
/* harmony export */   "kreirajToken": () => (/* binding */ kreirajToken),
/* harmony export */   "uporediLozinke": () => (/* binding */ uporediLozinke)
/* harmony export */ });
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__);


async function hash(lozinka) {
    const salt = await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().genSalt(10);
    let hashed = await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().hash(lozinka, salt);
    return hashed;
}
async function uporediLozinke(lozinka, hash) {
    const iste = await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().compare(lozinka, hash);
    return iste;
}
function kreirajToken(korisnik) {
    const sadrzaj = {
        mejl: korisnik.mejl,
        ime: korisnik.ime,
        prezime: korisnik.prezime
    };
    return jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().sign(sadrzaj, process.env.JWT_SECRET);
}


/***/ })

};
;