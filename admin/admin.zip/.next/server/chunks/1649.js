exports.id = 1649;
exports.ids = [1649];
exports.modules = {

/***/ 2681:
/***/ ((module) => {

// Exports
module.exports = {
	"form-file-upload": "DragDropFile_form-file-upload__s8oUB",
	"input-file-upload": "DragDropFile_input-file-upload__m3s3O",
	"label-file-upload": "DragDropFile_label-file-upload__YjUBs",
	"drag-active": "DragDropFile_drag-active__s9E5G",
	"upload-button": "DragDropFile_upload-button__OD9A7",
	"drag-file-element": "DragDropFile_drag-file-element__O8s5_"
};


/***/ }),

/***/ 1877:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__1IwEk",
	"footer__links": "Footer_footer__links__4Qw_h",
	"footer__links_link": "Footer_footer__links_link__HlLuj",
	"footer__copy": "Footer_footer__copy__uppE9"
};


/***/ }),

/***/ 3896:
/***/ ((module) => {

// Exports
module.exports = {
	"line": "Line_line___WM_V",
	"line__kvadrat": "Line_line__kvadrat__iNFK8",
	"line__linija": "Line_line__linija__olJpI"
};


/***/ }),

/***/ 4453:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "Navbar_navbar__OXCIL",
	"navbar_left": "Navbar_navbar_left__D3whc"
};


/***/ }),

/***/ 3207:
/***/ ((module) => {

// Exports
module.exports = {
	"page": "Page_page__965tE"
};


/***/ }),

/***/ 6606:
/***/ ((module) => {

// Exports
module.exports = {
	"product_card": "ProductCard_product_card__j9IkA",
	"product_card_image": "ProductCard_product_card_image__XirGR",
	"product_card_content": "ProductCard_product_card_content__Q38_J",
	"product_card_content_row": "ProductCard_product_card_content_row__a_diI",
	"product_card_content_button": "ProductCard_product_card_content_button__55OSn"
};


/***/ }),

/***/ 9749:
/***/ ((module) => {

// Exports
module.exports = {
	"profile": "Profile_profile__ZYL6z",
	"profile_toggle": "Profile_profile_toggle__RyDkL",
	"profile_dropdown": "Profile_profile_dropdown__vU0yK",
	"profile_dropdown_header": "Profile_profile_dropdown_header__FgATK",
	"profile_dropdown_data": "Profile_profile_dropdown_data__SK84V",
	"profile_dropdown_data_name": "Profile_profile_dropdown_data_name__OpDUk",
	"profile_dropdown_data_role": "Profile_profile_dropdown_data_role__pPvXJ",
	"profile_dropdown_data_mail": "Profile_profile_dropdown_data_mail__cPOsj",
	"profile_dropdown_link": "Profile_profile_dropdown_link__sBS1E"
};


/***/ }),

/***/ 5092:
/***/ ((module) => {

// Exports
module.exports = {
	"top_to_btm": "ScrollToTop_top_to_btm__b0Mao",
	"icon_position": "ScrollToTop_icon_position__9AK_9",
	"icon_style": "ScrollToTop_icon_style__ZawD6"
};


/***/ }),

/***/ 3031:
/***/ ((module) => {

// Exports
module.exports = {
	"sidebar": "SideBar_sidebar__BKnnR",
	"sidebar_brand": "SideBar_sidebar_brand__4ELu_",
	"sidebar_links": "SideBar_sidebar_links__pCgy6",
	"sidebar_link": "SideBar_sidebar_link__6HfuU",
	"sidebar_link_hoverable": "SideBar_sidebar_link_hoverable__8PKb7"
};


/***/ }),

/***/ 5032:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "form_form___uKw5",
	"form_row": "form_form_row__kB_41",
	"form_column": "form_form_column__8wX_g",
	"form_label": "form_form_label__d3hda",
	"form_label_error": "form_form_label_error__DBrWL",
	"form_input": "form_form_input__6IU09",
	"form_textarea": "form_form_textarea__x160r"
};


/***/ }),

/***/ 7452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "AN": () => (/* reexport */ DeleteDialog_DeleteDialog),
  "kY": () => (/* reexport */ DragDropFile),
  "$_": () => (/* reexport */ Footer_Footer),
  "OQ": () => (/* reexport */ GradientButton_GradientButton),
  "$x": () => (/* reexport */ Kvadrat_Kvadrat),
  "Ar": () => (/* reexport */ Layout_Layout),
  "x1": () => (/* reexport */ Line_Line),
  "aN": () => (/* reexport */ Loader_Loader),
  "u_": () => (/* reexport */ Modal_Modal),
  "wp": () => (/* reexport */ Navbar_Navbar),
  "Hn": () => (/* reexport */ OnDoubleClickInput),
  "T3": () => (/* reexport */ Page_Page),
  "V1": () => (/* reexport */ PageTitle_PageTitle),
  "Il": () => (/* reexport */ ProductCard_ProductCard),
  "HG": () => (/* reexport */ ProductForm),
  "cm": () => (/* reexport */ ProductList_ProductList),
  "NZ": () => (/* reexport */ Profile_Profile),
  "pU": () => (/* reexport */ ScrollToTop_ScrollToTop),
  "Ke": () => (/* reexport */ SideBar_SideBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Line/Line.module.css
var Line_module = __webpack_require__(3896);
var Line_module_default = /*#__PURE__*/__webpack_require__.n(Line_module);
;// CONCATENATED MODULE: ./components/Line/Line.jsx


function Line({ color , width  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Line_module_default()).line,
        style: {
            width
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Line_module_default()).line__kvadrat,
                style: {
                    background: color
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Line_module_default()).line__linija,
                style: {
                    background: color
                }
            })
        ]
    });
}
/* harmony default export */ const Line_Line = (Line);

;// CONCATENATED MODULE: ./components/Kvadrat/Kvadrat.jsx

function Kvadrat({ style  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            width: "10px",
            height: "10px",
            transform: "rotate(45deg)",
            background: "linear-gradient(238.66deg, #0283E9 -18.13%, #FC01CA 120.27%)",
            ...style
        }
    });
}
/* harmony default export */ const Kvadrat_Kvadrat = (Kvadrat);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./components/GradientButton/GradientButton.jsx


function GradientButton({ children , onClick , style , className , ...rest }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        onClick: onClick,
        style: {
            color: "white",
            outline: "none",
            border: "none",
            borderRadius: "15px",
            padding: "1rem 1.5rem",
            fontSize: "14px",
            cursor: "pointer",
            ...style
        },
        className: `gradient ${className ?? ""}`,
        ...rest,
        children: children
    });
}
/* harmony default export */ const GradientButton_GradientButton = (GradientButton);

// EXTERNAL MODULE: ./components/Page/Page.module.css
var Page_module = __webpack_require__(3207);
var Page_module_default = /*#__PURE__*/__webpack_require__.n(Page_module);
;// CONCATENATED MODULE: ./components/Page/Page.jsx


function Page({ children , style  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Page_module_default()).page,
        style: style,
        children: children
    });
}
/* harmony default export */ const Page_Page = (Page);

;// CONCATENATED MODULE: ./components/PageTitle/PageTitle.jsx

function PageTitle({ children , style , level , className  }) {
    return /*#__PURE__*/ external_react_default().createElement(`h${level && level >= 1 && level <= 6 ? level : 1}`, {
        style: {
            fontSize: 34,
            textAlign: "center",
            margin: "auto",
            marginBottom: "2rem",
            fontWeight: "bolder",
            width: "100%",
            ...style
        },
        className: `gradient_text ${className}`
    }, children);
}
/* harmony default export */ const PageTitle_PageTitle = (PageTitle);

// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./components/ScrollToTop/ScrollToTop.module.css
var ScrollToTop_module = __webpack_require__(5092);
var ScrollToTop_module_default = /*#__PURE__*/__webpack_require__.n(ScrollToTop_module);
;// CONCATENATED MODULE: ./components/ScrollToTop/ScrollToTop.jsx




const ScrollToTop = ()=>{
    const { 0: showTopBtn , 1: setShowTopBtn  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        document.getElementById("content")?.addEventListener("scroll", ()=>{
            if (document.getElementById("content")?.scrollTop > 400) {
                setShowTopBtn(true);
            } else {
                setShowTopBtn(false);
            }
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const goToTop = ()=>{
        document.getElementById("content")?.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (ScrollToTop_module_default()).top_to_btm,
        children: [
            " ",
            showTopBtn && /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleUp, {
                className: `${(ScrollToTop_module_default()).icon_position} ${(ScrollToTop_module_default()).icon_style}`,
                onClick: goToTop
            }),
            " "
        ]
    });
};
/* harmony default export */ const ScrollToTop_ScrollToTop = (ScrollToTop);

// EXTERNAL MODULE: external "react-spinners"
var external_react_spinners_ = __webpack_require__(8176);
;// CONCATENATED MODULE: ./components/Loader/Loader.jsx


function Loader({ show  }) {
    if (!show) return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "fixed",
            top: 0,
            left: 0,
            zIndex: 99999999,
            background: "rgba(200, 200, 200, 0.75)",
            width: "100vw",
            height: "100vh"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_spinners_.BounceLoader, {
            color: "#000000",
            size: 100
        })
    });
}
/* harmony default export */ const Loader_Loader = (Loader);

// EXTERNAL MODULE: ./components/SideBar/SideBar.module.css
var SideBar_module = __webpack_require__(3031);
var SideBar_module_default = /*#__PURE__*/__webpack_require__.n(SideBar_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: ./context/ContextProvider.js + 1 modules
var ContextProvider = __webpack_require__(7912);
;// CONCATENATED MODULE: ./components/SideBar/SideBar.jsx

/* eslint-disable react-hooks/exhaustive-deps */ 






const links = [
    {
        text: "Po\u010Detna",
        href: "/"
    },
    {
        text: "Terarijumi",
        href: "/terarijumi"
    },
    {
        text: "\u017Divotinje",
        href: "/zivotinje"
    },
    {
        text: "Oprema",
        href: "/oprema"
    },
    {
        text: "Hrana",
        href: "/hrana"
    },
    {
        text: "Porud\u017Ebine",
        href: "/porudzbine"
    },
    {
        text: "Ostalo",
        href: "/ostalo"
    }, 
];
function SideBar() {
    const { windowSize , setActiveMenu  } = (0,ContextProvider/* useStateContext */.F)();
    const router = (0,router_.useRouter)();
    function linkClik() {
        if (windowSize.width <= 900) setActiveMenu(false);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (SideBar_module_default()).sidebar,
        children: [
            windowSize.width <= 900 && /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                style: {
                    borderRadius: "50%",
                    width: 30,
                    height: 30,
                    padding: 0,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    position: "absolute",
                    top: "1.5rem",
                    right: "1.5rem"
                },
                onClick: ()=>setActiveMenu(false),
                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                    color: "white",
                    size: 15
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (SideBar_module_default()).sidebar_brand,
                        onClick: linkClik,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/logo-no-bg.png",
                                alt: "Logo",
                                width: 50,
                                height: 50
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "The reptile house"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (SideBar_module_default()).sidebar_links,
                children: links.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: item.href,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            onClick: linkClik,
                            className: `${(SideBar_module_default()).sidebar_link} ${router.pathname.startsWith(item.href) && item.href !== "/" || router.pathname === "/" && item.href === "/" ? "gradient text-white " : (SideBar_module_default()).sidebar_link_hoverable}`,
                            children: item.text
                        })
                    }, index))
            })
        ]
    });
}
/* harmony default export */ const SideBar_SideBar = (SideBar);

// EXTERNAL MODULE: ./components/Footer/Footer.module.css
var Footer_module = __webpack_require__(1877);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./components/Footer/Footer.jsx





const Footer_links = [
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiPhone, {
            style: {
                fill: "url(#footer-gradient)"
            }
        }),
        text: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            href: "tel:+381695466205",
            target: "_blank",
            rel: "noreferrer",
            children: "+381695466205"
        })
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiEnvelope, {
            style: {
                fill: "url(#footer-gradient)"
            }
        }),
        text: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            href: "mailto:thereptilehouse.info@gmail.com",
            target: "_blank",
            rel: "noreferrer",
            children: "thereptilehouse.info@gmail.com"
        })
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsInstagram, {
            style: {
                fill: "url(#footer-gradient)"
            }
        }),
        text: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            href: "https://www.instagram.com/thereptilehouse__/",
            target: "_blank",
            rel: "noreferrer",
            children: "thereptilehouse__"
        })
    }
];
function Link({ icon , text  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).footer__links_link,
        children: [
            icon,
            text
        ]
    });
}
function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (Footer_module_default()).footer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                width: "0",
                height: "0",
                style: {
                    visibility: "hidden"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                    id: "footer-gradient",
                    x1: "100%",
                    y1: "100%",
                    x2: "0%",
                    y2: "0%",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                            stopColor: "#0283E9",
                            offset: "-18.13%"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                            stopColor: "#FC01CA",
                            offset: "120.27%"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Footer_module_default()).footer__links,
                children: Footer_links.map((link, index)=>/*#__PURE__*/ jsx_runtime_.jsx(Link, {
                        ...link
                    }, index))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Line_Line, {
                color: "black",
                width: "20%"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: (Footer_module_default()).footer__copy,
                children: [
                    "Copyright \xa9 ",
                    (new Date).getFullYear(),
                    " The reptile house "
                ]
            })
        ]
    });
}
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: ./components/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(4453);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
;// CONCATENATED MODULE: ./components/Navbar/Navbar.jsx






function Navbar() {
    const navRef = (0,external_react_.useRef)(null);
    const { windowSize , setActiveMenu , korisnik , setNavHeight , navHeight  } = (0,ContextProvider/* useStateContext */.F)();
    (0,external_react_.useEffect)(()=>{
        setNavHeight(navRef.current.clientHeight);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        windowSize
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(Navbar_module_default()).navbar} `,
        ref: navRef,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Navbar_module_default()).navbar_left,
                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineMenu, {
                    onClick: ()=>setActiveMenu((prev)=>!prev),
                    size: 25
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Navbar_module_default()).navbar_right,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Profile_Profile, {})
            })
        ]
    });
}
/* harmony default export */ const Navbar_Navbar = (Navbar);

;// CONCATENATED MODULE: ./components/Modal/Modal.jsx


function Modal({ show , children  }) {
    const { windowSize  } = (0,ContextProvider/* useStateContext */.F)();
    if (!show) return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "fixed",
            top: 0,
            left: 0,
            zIndex: 99999999,
            background: "rgba(200, 200, 200, 0.75)",
            width: "100vw",
            height: "100vh",
            padding: "1rem"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                width: windowSize.width <= 500 ? "100%" : windowSize.width <= 900 ? "80%" : "60%",
                height: windowSize.width <= 500 ? "100%" : "80%",
                background: "white",
                padding: windowSize.width <= 500 ? "1rem" : "2rem",
                borderRadius: 15
            },
            className: "box-shadow",
            children: children
        })
    });
}
/* harmony default export */ const Modal_Modal = (Modal);

// EXTERNAL MODULE: ./components/Profile/Profile.module.css
var Profile_module = __webpack_require__(9749);
var Profile_module_default = /*#__PURE__*/__webpack_require__.n(Profile_module);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
;// CONCATENATED MODULE: ./components/Profile/Profile.jsx









function Profile() {
    const { 0: openDropdown , 1: setOpenDropdown  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const { korisnik , setLoader , createNotification , notificationTypes  } = (0,ContextProvider/* useStateContext */.F)();
    async function logout() {
        try {
            const res = await fetch("/api/logout");
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            createNotification({
                type: notificationTypes.SUCCESS,
                message: "Uspe\u0161no ste se odjavili",
                title: "Uspre\u0161na odjava"
            });
            router.push("/login");
        } catch (error) {
            createNotification({
                type: notificationTypes.ERROR,
                message: error.message
            });
        } finally{
            setLoader(false);
        }
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Profile_module_default()).profile,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: (Profile_module_default()).profile_toggle,
                onClick: ()=>setOpenDropdown((prev)=>!prev),
                children: [
                    korisnik.ime[0].toUpperCase(),
                    ". ",
                    korisnik.prezime
                ]
            }),
            openDropdown && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(Profile_module_default()).profile_dropdown} box-shadow`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Profile_module_default()).profile_dropdown_header,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "Korisni\u010Dki profil"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                style: {
                                    borderRadius: "50%",
                                    width: 30,
                                    height: 30,
                                    padding: 0,
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center"
                                },
                                onClick: ()=>setOpenDropdown(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                                    color: "white",
                                    size: 15
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Profile_module_default()).profile_dropdown_data,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: (Profile_module_default()).profile_dropdown_data_name,
                                children: [
                                    korisnik.ime,
                                    " ",
                                    korisnik.prezime
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (Profile_module_default()).profile_dropdown_data_role,
                                children: "Administrator"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (Profile_module_default()).profile_dropdown_data_mail,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    target: "_blank",
                                    rel: "noreferrer",
                                    href: `mailto:${korisnik.mejl}`,
                                    children: korisnik.mejl
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            margin: 0,
                            padding: 0
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Line_Line, {
                            color: "#555555",
                            width: "50%"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/promena-lozinke",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Profile_module_default()).profile_dropdown_link,
                            onClick: ()=>setOpenDropdown(false),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiLockPasswordLine, {
                                    color: "black"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Promeni lozinku"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            margin: 0,
                            padding: 0
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Line_Line, {
                            color: "#555555",
                            width: "50%"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Profile_module_default()).profile_dropdown_link,
                        onClick: ()=>{
                            setOpenDropdown(false);
                            logout();
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiLogoutCircleRLine, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Odjavi se"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Profile_Profile = (Profile);

;// CONCATENATED MODULE: ./components/Layout/Layout.jsx




function Layout({ children  }) {
    const { activeMenu , windowSize  } = (0,ContextProvider/* useStateContext */.F)();
    const router = (0,router_.useRouter)();
    if (router.pathname === "/login") return children;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                display: "flex",
                width: "100%",
                minHeight: "100vh",
                position: "relative"
            },
            children: [
                activeMenu ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        width: "18rem",
                        height: "100%",
                        position: "fixed",
                        zIndex: 5000,
                        background: "white",
                        paddingBottom: "2rem"
                    },
                    className: "hover-scroll box-shadow",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SideBar_SideBar, {})
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        width: 0
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    style: {
                        width: windowSize.width > 900 && activeMenu ? "calc(100% - 18rem)" : "100%",
                        height: "100%",
                        position: "fixed",
                        right: 0,
                        overflowX: "hidden",
                        zIndex: 3000
                    },
                    id: "content",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Navbar, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(Page_Page, {
                            children: children
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(ScrollToTop_ScrollToTop, {})
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const Layout_Layout = (Layout);

// EXTERNAL MODULE: ./styles/form.module.css
var form_module = __webpack_require__(5032);
var form_module_default = /*#__PURE__*/__webpack_require__.n(form_module);
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
// EXTERNAL MODULE: external "react-icons/io"
var io_ = __webpack_require__(4751);
// EXTERNAL MODULE: external "@mui/material/Switch"
var Switch_ = __webpack_require__(3191);
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch_);
// EXTERNAL MODULE: external "@mui/material/FormControlLabel"
var FormControlLabel_ = __webpack_require__(8185);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_);
// EXTERNAL MODULE: external "@mui/material/Checkbox"
var Checkbox_ = __webpack_require__(8330);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_);
// EXTERNAL MODULE: external "@mui/material/Menu"
var Menu_ = __webpack_require__(8125);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/material/MenuItem"
var MenuItem_ = __webpack_require__(9271);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem_);
// EXTERNAL MODULE: external "@mui/material/ListItemText"
var ListItemText_ = __webpack_require__(8315);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);
// EXTERNAL MODULE: external "@mui/material/ListItemIcon"
var ListItemIcon_ = __webpack_require__(3787);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon_);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/ImageList"
var ImageList_ = __webpack_require__(4287);
var ImageList_default = /*#__PURE__*/__webpack_require__.n(ImageList_);
// EXTERNAL MODULE: external "@mui/material/ImageListItem"
var ImageListItem_ = __webpack_require__(4298);
var ImageListItem_default = /*#__PURE__*/__webpack_require__.n(ImageListItem_);
;// CONCATENATED MODULE: ./utils/hooks/useStateWithCallback.js

const useStateWithCallback = (initialValue)=>{
    const { 0: value , 1: setValue  } = (0,external_react_.useState)(initialValue);
    const setValueAndCallback = (newValue, callback)=>{
        setValue((prevValue)=>{
            if (callback) {
                callback(prevValue, newValue);
            }
            return newValue;
        });
    };
    return [
        value,
        setValueAndCallback
    ];
};
/* harmony default export */ const hooks_useStateWithCallback = (useStateWithCallback);

// EXTERNAL MODULE: external "react-color"
var external_react_color_ = __webpack_require__(1711);
;// CONCATENATED MODULE: ./components/ProductForm/ProductForm.jsx

/* eslint-disable @next/next/no-img-element */ /* eslint-disable react-hooks/exhaustive-deps */ 





















// const IMAGE_HOST = "http://localhost:10000";
const IMAGE_HOST = "https://thereptilehouse.rs";
function getFormData(proizvod) {
    return {
        naziv: {
            value: proizvod?.naziv ?? "",
            error: ""
        },
        cena: {
            value: proizvod?.cena ?? "",
            error: ""
        },
        preporuceno: {
            checked: !!proizvod?.preporuceno
        },
        thumbnail: {
            value: proizvod?.thumbnail ?? null,
            error: ""
        },
        slike: {
            value: proizvod?.slike ?? [],
            error: ""
        },
        dodaci: {
            value: proizvod?.dodaci ?? [],
            error: ""
        },
        boje: {
            value: proizvod?.boje ?? [],
            error: ""
        },
        opis: {
            value: proizvod?.opis ?? "",
            error: ""
        },
        duzina: {
            value: proizvod?.dimenzije?.duzina ?? "",
            error: ""
        },
        sirina: {
            value: proizvod?.dimenzije?.sirina ?? "",
            error: ""
        },
        visina: {
            value: proizvod?.dimenzije?.visina ?? "",
            error: ""
        },
        vrsta: {
            value: proizvod?.vrsta ?? "",
            error: ""
        },
        morf: {
            value: proizvod?.morf ?? "",
            error: ""
        },
        pol: {
            value: proizvod?.pol ?? "",
            error: ""
        },
        vreme: {
            value: proizvod?.vreme ?? "",
            error: ""
        },
        roditelji: {
            value: proizvod?.roditelji ?? "",
            error: ""
        },
        tezina: {
            value: proizvod?.tezina ?? "",
            error: ""
        },
        ostecenja: {
            value: proizvod?.ostecenja ?? "",
            error: ""
        }
    };
}
const fields = {
    "terarijumi": {
        opis: true,
        duzina: true,
        sirina: true,
        visina: true,
        vrsta: false,
        morf: false,
        pol: false,
        vreme: false,
        roditelji: false,
        tezina: false,
        ostecenja: false,
        dodaci: true,
        boje: true
    },
    "zivotinje": {
        opis: false,
        duzina: false,
        sirina: false,
        visina: false,
        vrsta: true,
        morf: true,
        pol: true,
        vreme: true,
        roditelji: true,
        tezina: true,
        ostecenja: true,
        dodaci: false,
        boje: false
    },
    "hrana": {
        opis: true,
        duzina: false,
        sirina: false,
        visina: false,
        vrsta: false,
        morf: false,
        pol: false,
        vreme: false,
        roditelji: false,
        tezina: false,
        ostecenja: false,
        dodaci: false,
        boje: false
    },
    "oprema": {
        opis: true,
        duzina: false,
        sirina: false,
        visina: false,
        vrsta: false,
        morf: false,
        pol: false,
        vreme: false,
        roditelji: false,
        tezina: false,
        ostecenja: false,
        dodaci: false,
        boje: false
    }
};
function ProductForm({ kategorija , proizvod , onSave  }) {
    const prikaz = fields[kategorija];
    const router = (0,router_.useRouter)();
    const { createNotification , notificationTypes , setLoader  } = (0,ContextProvider/* useStateContext */.F)();
    const [slike, setSlike] = hooks_useStateWithCallback([]);
    const [dodaci, setDodaci] = hooks_useStateWithCallback([]);
    const [boje, setBoje] = hooks_useStateWithCallback([]);
    const { 0: formData , 1: setFormData  } = (0,external_react_.useState)(getFormData(proizvod));
    const fetchSlike = (0,external_react_.useCallback)(async (cb, errcb)=>{
        try {
            setLoader(true);
            const res = await fetch(`/api/slike/${kategorija}`);
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            setSlike(json.data, cb);
            setTimeout(()=>{
                setLoader(false);
            }, 1 * 1000);
        } catch (error) {
            setTimeout(()=>{
                setLoader(false);
                createNotification({
                    type: notificationTypes.ERROR,
                    message: error.message
                });
                errcb?.();
            }, 1 * 1000);
        }
    }, []);
    const fetchDodaciBoje = (0,external_react_.useCallback)(async (cb, errcb)=>{
        try {
            setLoader(true);
            const res = await fetch(`/api/terarijumi/dodaci-boje`);
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            setDodaci(json.data.dodaci, cb);
            setBoje(json.data.boje, cb);
            setTimeout(()=>{
                setLoader(false);
            }, 1 * 1000);
        } catch (error) {
            setTimeout(()=>{
                setLoader(false);
                createNotification({
                    type: notificationTypes.ERROR,
                    message: error.message
                });
                errcb?.();
            }, 1 * 1000);
        }
    }, []);
    (0,external_react_.useEffect)(()=>{
        setFormData(getFormData(proizvod));
    }, [
        proizvod
    ]);
    (0,external_react_.useEffect)(()=>{
        fetchSlike(null, ()=>router.push(`/${kategorija}`));
        if (kategorija === "terarijumi") fetchDodaciBoje(null, ()=>router.push("/terarijumi"));
    }, []);
    async function uploadFiles(files) {
        try {
            if (Array.from(files).length === 0) return;
            setLoader(true);
            const body = new FormData();
            Array.from(files).forEach((file, index)=>body.append("image" + index, file));
            body.append("kategorija", kategorija);
            const res = await fetch(`${IMAGE_HOST}/api/images`, {
                method: "POST",
                body
            });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            return json;
        } catch (error) {
            console.error(error);
            createNotification({
                type: notificationTypes.ERROR,
                message: error.message
            });
            setLoader(false);
            return null;
        }
    }
    async function dodajThumbnail(files) {
        const json = await uploadFiles(files);
        fetchSlike((_, slike)=>{
            setFormData({
                ...formData,
                thumbnail: {
                    value: slike.find((slika)=>slika.id === json.ids[0]).src,
                    error: ""
                }
            });
        });
    }
    async function dodajSlike(files) {
        const json = await uploadFiles(files);
        fetchSlike((_, slike)=>{
            setFormData({
                ...formData,
                slike: {
                    value: [
                        ...formData.slike.value,
                        ...json.ids.map((id)=>slike.find((slika)=>slika.id === id))
                    ],
                    error: ""
                }
            });
        });
    }
    async function dodajBoju(hex) {
        try {
            if (!hex) return;
            setLoader(true);
            const res = await fetch(`/api/terarijumi/boje`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    hex
                })
            });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            fetchDodaciBoje((_, boje)=>{
                if (!boje[0]?.hasOwnProperty("hex")) return;
                setFormData({
                    ...formData,
                    boje: {
                        value: [
                            ...formData.boje.value,
                            boje.find((boja)=>boja.hex === hex)
                        ],
                        error: ""
                    }
                });
            });
        } catch (error) {
            console.error(error);
            createNotification({
                type: notificationTypes.ERROR,
                message: error.message
            });
            setLoader(false);
        }
    }
    async function dodajDodatak(naziv) {
        try {
            if (!naziv) return;
            setLoader(true);
            const res = await fetch(`/api/terarijumi/dodaci`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    naziv
                })
            });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            fetchDodaciBoje((_, dodaci)=>{
                if (typeof dodaci[0] !== "string") return;
                setFormData({
                    ...formData,
                    dodaci: {
                        value: [
                            ...formData.dodaci.value,
                            naziv
                        ],
                        error: ""
                    }
                });
            });
        } catch (error) {
            console.error(error);
            createNotification({
                type: notificationTypes.ERROR,
                message: error.message
            });
            setLoader(false);
        }
    }
    function handleChange(e) {
        setFormData({
            ...formData,
            [e.target.name]: {
                ...formData[e.target.name],
                value: e.target.value
            }
        });
    }
    async function handleSubmit(e) {
        e.preventDefault();
        let hasError = false;
        let formDataCopy = {
            ...formData
        };
        if (!formDataCopy.naziv.value) {
            formDataCopy.naziv.error = "Morate uneti naziv.";
            hasError = true;
        } else {
            formDataCopy.naziv.error = "";
        }
        if (!formDataCopy.cena.value) {
            formDataCopy.cena.error = "Morate uneti cenu.";
            hasError = true;
        } else {
            formDataCopy.cena.error = "";
        }
        if (!formDataCopy.thumbnail.value) {
            formDataCopy.thumbnail.error = "Morate uneti thumbnail.";
            hasError = true;
        } else {
            formDataCopy.thumbnail.error = "";
        }
        if (formDataCopy.slike.value.length === 0) {
            formDataCopy.slike.error = "Morate uneti makar jednu sliku.";
            hasError = true;
        } else {
            formDataCopy.slike.error = "";
        }
        if (prikaz.opis) {
            if (!formDataCopy.opis.value) {
                formDataCopy.opis.error = "Morate uneti opis.";
                hasError = true;
            } else {
                formDataCopy.opis.error = "";
            }
        }
        if (prikaz.duzina) {
            if (!formDataCopy.duzina.value) {
                formDataCopy.duzina.error = "Morate uneti du\u017Einu.";
                hasError = true;
            } else {
                formDataCopy.duzina.error = "";
            }
        }
        if (prikaz.visina) {
            if (!formDataCopy.visina.value) {
                formDataCopy.visina.error = "Morate uneti visinu.";
                hasError = true;
            } else {
                formDataCopy.visina.error = "";
            }
        }
        if (prikaz.sirina) {
            if (!formDataCopy.sirina.value) {
                formDataCopy.sirina.error = "Morate uneti \u0161irinu.";
                hasError = true;
            } else {
                formDataCopy.sirina.error = "";
            }
        }
        if (prikaz.vrsta) {
            if (!formDataCopy.vrsta.value) {
                formDataCopy.vrsta.error = "Morate uneti vrstu.";
                hasError = true;
            } else {
                formDataCopy.vrsta.error = "";
            }
        }
        if (prikaz.morf) {
            if (!formDataCopy.morf.value) {
                formDataCopy.morf.error = "Morate uneti morf.";
                hasError = true;
            } else {
                formDataCopy.morf.error = "";
            }
        }
        if (prikaz.pol) {
            if (!formDataCopy.pol.value) {
                formDataCopy.pol.error = "Morate uneti pol.";
                hasError = true;
            } else {
                formDataCopy.pol.error = "";
            }
        }
        if (prikaz.vreme) {
            if (!formDataCopy.vreme.value) {
                formDataCopy.vreme.error = "Morate uneti vreme izleganja.";
                hasError = true;
            } else {
                formDataCopy.vreme.error = "";
            }
        }
        if (prikaz.roditelji) {
            if (!formDataCopy.roditelji.value) {
                formDataCopy.roditelji.error = "Morate uneti roditelje.";
                hasError = true;
            } else {
                formDataCopy.roditelji.error = "";
            }
        }
        if (prikaz.tezina) {
            if (!formDataCopy.tezina.value) {
                formDataCopy.tezina.error = "Morate uneti te\u017Einu.";
                hasError = true;
            } else {
                formDataCopy.tezina.error = "";
            }
        }
        if (prikaz.ostecenja) {
            if (!formDataCopy.ostecenja.value) {
                formDataCopy.ostecenja.error = "Morate uneti o\u0161te\u0107enja.";
                hasError = true;
            } else {
                formDataCopy.ostecenja.error = "";
            }
        }
        if (prikaz.boje) {
            if (formDataCopy.boje.value.length === 0) {
                formDataCopy.boje.error = "Morate uneti makar jednu boju.";
                hasError = true;
            } else {
                formDataCopy.boje.error = "";
            }
        }
        if (prikaz.dodaci) {
            if (formDataCopy.dodaci.value.length === 0) {
                formDataCopy.dodaci.error = "Morate uneti makar jedan dodatak.";
                hasError = true;
            } else {
                formDataCopy.dodaci.error = "";
            }
        }
        if (hasError) {
            setFormData(formDataCopy);
            return;
        }
        console.log(formData, hasError);
        onSave?.(formData);
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: handleSubmit,
            className: (form_module_default()).form,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "naziv",
                                    children: "Naziv *"
                                }),
                                formData.naziv.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.naziv.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "naziv",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "naziv",
                            value: formData.naziv.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.opis && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "opis",
                                    children: "Opis *"
                                }),
                                formData.opis.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.opis.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            id: "opis",
                            type: "text",
                            className: (form_module_default()).form_textarea,
                            name: "opis",
                            value: formData.opis.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.duzina && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "duzina",
                                    children: "Du\u017Eina *"
                                }),
                                formData.duzina.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.duzina.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "duzina",
                            min: 0,
                            step: 0.01,
                            type: "number",
                            className: (form_module_default()).form_input,
                            name: "duzina",
                            value: formData.duzina.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.sirina && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "sirina",
                                    children: "\u0160irina *"
                                }),
                                formData.sirina.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.sirina.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "sirina",
                            min: 0,
                            step: 0.01,
                            type: "number",
                            className: (form_module_default()).form_input,
                            name: "sirina",
                            value: formData.sirina.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.visina && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "visina",
                                    children: "Visina *"
                                }),
                                formData.visina.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.visina.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "visina",
                            min: 0,
                            step: 0.01,
                            type: "number",
                            className: (form_module_default()).form_input,
                            name: "visina",
                            value: formData.visina.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.vrsta && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "vrsta",
                                    children: "Vrsta *"
                                }),
                                formData.vrsta.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.vrsta.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "vrsta",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "vrsta",
                            value: formData.vrsta.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.morf && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "morf",
                                    children: "Morf *"
                                }),
                                formData.morf.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.morf.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "morf",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "morf",
                            value: formData.morf.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.pol && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "pol",
                                    children: "Pol *"
                                }),
                                formData.pol.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.pol.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "pol",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "pol",
                            value: formData.pol.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.vreme && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "vreme",
                                    children: "Vreme izleganja *"
                                }),
                                formData.vreme.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.vreme.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "vreme",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "vreme",
                            value: formData.vreme.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.roditelji && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "roditelji",
                                    children: "Roditelji *"
                                }),
                                formData.roditelji.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.roditelji.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "roditelji",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "roditelji",
                            value: formData.roditelji.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.tezina && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "tezina",
                                    children: "Te\u017Eina *"
                                }),
                                formData.tezina.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.tezina.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "tezina",
                            type: "text",
                            className: (form_module_default()).form_input,
                            name: "tezina",
                            value: formData.tezina.value,
                            onChange: handleChange
                        })
                    ]
                }),
                prikaz.ostecenja && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "ostecenja",
                                    children: "Vidljiva o\u0161te\u0107enja *"
                                }),
                                formData.ostecenja.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.ostecenja.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            id: "ostecenja",
                            type: "text",
                            className: (form_module_default()).form_textarea,
                            name: "ostecenja",
                            value: formData.ostecenja.value,
                            onChange: handleChange
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "cena",
                                    children: "Cena *"
                                }),
                                formData.cena.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.cena.error
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "cena",
                            min: 0,
                            step: 0.01,
                            type: "number",
                            className: (form_module_default()).form_input,
                            name: "cena",
                            value: formData.cena.value,
                            onChange: handleChange
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (form_module_default()).form_column,
                    style: {
                        alignItems: "flex-start"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                            checked: formData.preporuceno.checked,
                            onChange: (e)=>setFormData({
                                    ...formData,
                                    preporuceno: {
                                        checked: e.target.checked
                                    }
                                }),
                            color: "secondary"
                        }),
                        label: `Preporučeno`,
                        labelPlacement: "start"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                    style: {
                                        display: "flex",
                                        gap: "1rem",
                                        justifyContent: "flex-start",
                                        alignItems: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Thumbnail *"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(DodajSlike, {
                                            slike: slike?.filter((slika)=>slika.src !== formData.thumbnail.value),
                                            dodajNovu: dodajThumbnail,
                                            odaberiPostojecu: (slike)=>setFormData({
                                                    ...formData,
                                                    thumbnail: {
                                                        value: slike[0].src,
                                                        error: ""
                                                    }
                                                })
                                        })
                                    ]
                                }),
                                formData.thumbnail.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.thumbnail.error
                                })
                            ]
                        }),
                        formData.thumbnail.value && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "1rem",
                                flexWrap: "wrap",
                                background: "white",
                                border: "1px solid black",
                                borderRadius: 15,
                                padding: "1rem",
                                width: "100%",
                                minHeight: 100
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                style: {
                                    width: "auto",
                                    height: 100,
                                    margin: "auto",
                                    position: "relative"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        alt: "thumbnail image",
                                        src: `${IMAGE_HOST}${formData.thumbnail.value}`,
                                        style: {
                                            objectFit: "contain",
                                            width: "100%",
                                            height: "100%"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                        type: "button",
                                        style: {
                                            borderRadius: "50%",
                                            width: 20,
                                            height: 20,
                                            padding: 0,
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            position: "absolute",
                                            top: -10,
                                            right: -10,
                                            zIndex: 99999
                                        },
                                        onClick: ()=>{
                                            setFormData({
                                                ...formData,
                                                thumbnail: {
                                                    error: "",
                                                    value: null
                                                }
                                            });
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                                            color: "white",
                                            size: 15
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                    style: {
                                        display: "flex",
                                        gap: "1rem",
                                        justifyContent: "flex-start",
                                        alignItems: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Slike *"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(DodajSlike, {
                                            slike: slike?.filter((slika)=>!formData.slike.value.map((item)=>item.id).join(", ").includes(slika.id)),
                                            dodajNovu: dodajSlike,
                                            odaberiPostojecu: (slike)=>setFormData({
                                                    ...formData,
                                                    slike: {
                                                        value: [
                                                            ...formData.slike.value,
                                                            ...slike
                                                        ],
                                                        error: ""
                                                    }
                                                }),
                                            multiple: true
                                        })
                                    ]
                                }),
                                formData.slike.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.slike.error
                                })
                            ]
                        }),
                        formData.slike.value.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "1rem",
                                flexWrap: "wrap",
                                background: "white",
                                border: "1px solid black",
                                borderRadius: 15,
                                padding: "1rem",
                                width: "100%",
                                minHeight: 100
                            },
                            children: formData.slike.value.map((slika, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        width: "auto",
                                        height: 100,
                                        margin: "auto",
                                        position: "relative"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            alt: `Slika ${index}`,
                                            src: `${IMAGE_HOST}${slika.src}`,
                                            style: {
                                                objectFit: "contain",
                                                width: "100%",
                                                height: "100%"
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                            type: "button",
                                            style: {
                                                borderRadius: "50%",
                                                width: 20,
                                                height: 20,
                                                padding: 0,
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                                position: "absolute",
                                                top: -10,
                                                right: -10,
                                                zIndex: 99999
                                            },
                                            onClick: ()=>{
                                                setFormData({
                                                    ...formData,
                                                    slike: {
                                                        error: "",
                                                        value: formData.slike.value.filter((item)=>item.src !== slika.src)
                                                    }
                                                });
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                                                color: "white",
                                                size: 15
                                            })
                                        })
                                    ]
                                }, index))
                        })
                    ]
                }),
                prikaz.boje && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                    style: {
                                        display: "flex",
                                        gap: "1rem",
                                        justifyContent: "flex-start",
                                        alignItems: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Boje *"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(DodajBoje, {
                                            dodajNovu: dodajBoju,
                                            odaberiPostojecu: (boje)=>setFormData({
                                                    ...formData,
                                                    boje: {
                                                        error: "",
                                                        value: [
                                                            ...formData.boje.value,
                                                            ...boje
                                                        ]
                                                    }
                                                }),
                                            boje: boje
                                        })
                                    ]
                                }),
                                formData.boje.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.boje.error
                                })
                            ]
                        }),
                        formData.boje.value.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "1rem",
                                flexWrap: "wrap",
                                background: "white",
                                border: "1px solid black",
                                borderRadius: 15,
                                padding: "1rem",
                                width: "100%",
                                minHeight: 100
                            },
                            children: formData.boje.value.map((boja, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        width: 50,
                                        height: 50,
                                        margin: "auto",
                                        position: "relative",
                                        background: boja.hex,
                                        border: "1px solid black",
                                        borderRadius: "50%"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                        type: "button",
                                        style: {
                                            borderRadius: "50%",
                                            width: 20,
                                            height: 20,
                                            padding: 0,
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            position: "absolute",
                                            top: -5,
                                            right: -5,
                                            zIndex: 99999
                                        },
                                        onClick: ()=>{
                                            setFormData({
                                                ...formData,
                                                boje: {
                                                    error: "",
                                                    value: formData.boje.value.filter((item)=>item.hex !== boja.hex)
                                                }
                                            });
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                                            color: "white",
                                            size: 15
                                        })
                                    })
                                }, index))
                        })
                    ]
                }),
                prikaz.dodaci && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (form_module_default()).form_label,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                    style: {
                                        display: "flex",
                                        gap: "1rem",
                                        justifyContent: "flex-start",
                                        alignItems: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Dodaci"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(DodajDodatke, {
                                            dodajNov: dodajDodatak,
                                            odaberiPostojeci: (dodaci)=>setFormData({
                                                    ...formData,
                                                    dodaci: {
                                                        error: "",
                                                        value: [
                                                            ...formData.dodaci.value,
                                                            ...dodaci
                                                        ]
                                                    }
                                                }),
                                            dodaci: dodaci.filter((dodatak)=>formData.dodaci.value.findIndex((item)=>item === dodatak) < 0)
                                        })
                                    ]
                                }),
                                formData.dodaci.error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (form_module_default()).form_label_error,
                                    children: formData.dodaci.error
                                })
                            ]
                        }),
                        formData.dodaci.value.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                width: "100%",
                                display: "flex",
                                justifyContent: "flex-start",
                                alignItems: "flex-start"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                style: {
                                    listStyle: "none",
                                    margin: 0
                                },
                                children: formData.dodaci.value.map((dodatak, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        style: {
                                            width: "100%",
                                            paddingLeft: "0.75rem",
                                            paddingRight: "0.75rem",
                                            display: "flex",
                                            justifyContent: "flex-start",
                                            alignItems: "center",
                                            gap: "1rem",
                                            marginBottom: "0.5rem"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Kvadrat_Kvadrat, {}),
                                            dodatak,
                                            /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                                type: "button",
                                                style: {
                                                    borderRadius: "50%",
                                                    width: 20,
                                                    height: 20,
                                                    padding: 0,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                    zIndex: 99999
                                                },
                                                onClick: ()=>{
                                                    setFormData({
                                                        ...formData,
                                                        dodaci: {
                                                            error: "",
                                                            value: formData.dodaci.value.filter((item)=>item !== dodatak)
                                                        }
                                                    });
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                                                    color: "white",
                                                    size: 15
                                                })
                                            })
                                        ]
                                    }, index))
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (form_module_default()).form_row,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        type: "submit",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "1rem",
                                paddingLeft: "1rem",
                                paddingRight: "1rem"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiSave, {
                                    color: "white",
                                    size: 25
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Sa\u010Duvaj"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
function MasonryImageList({ images , selected , setSelected  }) {
    const { 0: cols , 1: setCols  } = (0,external_react_.useState)(1);
    const { windowSize  } = (0,ContextProvider/* useStateContext */.F)();
    (0,external_react_.useEffect)(()=>{
        if (windowSize.width <= 500) setCols(1);
        else if (windowSize.width <= 700) setCols(2);
        else if (windowSize.width <= 900) setCols(3);
        else if (windowSize.width <= 1200) setCols(4);
        else if (windowSize.width <= 1600) setCols(5);
        else if (windowSize.width <= 2000) setCols(6);
        else setCols(7);
    }, [
        windowSize
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
        sx: {
            width: "100%",
            height: "100%",
            overflowY: "scroll"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((ImageList_default()), {
            variant: "masonry",
            cols: cols,
            gap: 8,
            children: images.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((ImageListItem_default()), {
                    style: {
                        ...selected.findIndex((selected_index)=>selected_index === index) >= 0 ? {
                            border: "5px dashed   #0283E9"
                        } : {}
                    },
                    onClick: ()=>{
                        if (selected.findIndex((selected_index)=>selected_index === index) >= 0) setSelected(selected.filter((selected_index)=>selected_index !== index));
                        else setSelected([
                            ...selected,
                            index
                        ]);
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: `${IMAGE_HOST}${item.src}`,
                        alt: item.src,
                        loading: "lazy"
                    })
                }, item.src))
        })
    });
}
function OdabirPostojeceSlike({ slike , odaberiPostojecu , multiple  }) {
    const { 0: selected , 1: setSelected  } = (0,external_react_.useState)([]);
    const { setModalOpen  } = (0,ContextProvider/* useStateContext */.F)();
    (0,external_react_.useEffect)(()=>{
        const last = selected[selected.length - 1] ?? -1;
        if (multiple || selected.length === 1 || last < 0) return;
        setSelected([
            last
        ]);
    }, [
        selected
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "1.5rem"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    flex: 1,
                    overflow: "hidden",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center"
                },
                children: slike.length ? /*#__PURE__*/ jsx_runtime_.jsx(MasonryImageList, {
                    images: slike,
                    selected: selected,
                    setSelected: setSelected
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(PageTitle_PageTitle, {
                        level: 6,
                        style: {
                            fontSize: 24,
                            margin: 0
                        },
                        children: "Nema slika za prikaz"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "1.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            odaberiPostojecu(selected.map((index)=>slike[index]));
                            setModalOpen(false);
                        },
                        children: "Odaberi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setModalOpen(false);
                        },
                        children: "Odustani"
                    })
                ]
            })
        ]
    });
}
function OdabirPostojeceBoje({ boje , odaberiPostojecu  }) {
    const { 0: selected , 1: setSelected  } = (0,external_react_.useState)([]);
    const { setModalOpen  } = (0,ContextProvider/* useStateContext */.F)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "1.5rem"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    flex: 1,
                    overflow: "hidden",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: "1rem",
                        flexWrap: "wrap",
                        borderRadius: 15,
                        padding: "1rem",
                        width: "100%"
                    },
                    children: boje.map((boja, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                width: 50,
                                height: 50,
                                margin: "auto",
                                position: "relative",
                                boxSizing: "content-box",
                                background: boja.hex,
                                border: selected.findIndex((selected_index)=>selected_index === index) < 0 ? "1px solid black" : "5px dashed #0283E9",
                                borderRadius: "50%"
                            },
                            onClick: ()=>{
                                if (selected.findIndex((selected_index)=>selected_index === index) >= 0) setSelected(selected.filter((selected_index)=>selected_index !== index));
                                else setSelected([
                                    ...selected,
                                    index
                                ]);
                            }
                        }, index))
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "1.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            odaberiPostojecu(selected.map((index)=>boje[index]));
                            setModalOpen(false);
                        },
                        children: "Odaberi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setModalOpen(false);
                        },
                        children: "Odustani"
                    })
                ]
            })
        ]
    });
}
function OdabirPostojecegDodatka({ dodaci , odaberiPostojeci  }) {
    const { 0: selected , 1: setSelected  } = (0,external_react_.useState)([]);
    const { setModalOpen  } = (0,ContextProvider/* useStateContext */.F)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "1.5rem"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    flex: 1,
                    overflow: "hidden",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "flex-start",
                    alignItems: "flex-start",
                    width: "100%"
                },
                children: dodaci.length === 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(PageTitle_PageTitle, {
                        level: 6,
                        style: {
                            fontSize: 24,
                            margin: 0
                        },
                        children: "Nema dodataka za prikaz"
                    })
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        overflowY: "auto",
                        overflowX: "hidden",
                        width: "100%",
                        flex: 1
                    },
                    children: dodaci.map((dodatak, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                    checked: selected.findIndex((selected_index)=>selected_index === index) >= 0,
                                    onChange: (e)=>selected.findIndex((selected_index)=>selected_index === index) >= 0 ? setSelected(selected.filter((selected_index)=>selected_index !== index)) : setSelected([
                                            ...selected,
                                            index
                                        ]),
                                    color: "secondary"
                                }),
                                label: dodatak,
                                labelPlacement: "end"
                            })
                        }, index))
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "1.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            odaberiPostojeci(selected.map((index)=>dodaci[index]));
                            setModalOpen(false);
                        },
                        children: "Odaberi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setModalOpen(false);
                        },
                        children: "Odustani"
                    })
                ]
            })
        ]
    });
}
function DodavanjeNoveSlike({ dodajNovu  }) {
    const { setModalOpen  } = (0,ContextProvider/* useStateContext */.F)();
    const inputRef = (0,external_react_.useRef)(null);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "1.5rem"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    flex: 1,
                    overflow: "hidden",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(DragDropFile, {
                    inputRef: inputRef
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "1.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            dodajNovu(inputRef.current.files);
                            setModalOpen(false);
                        },
                        children: "Odaberi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setModalOpen(false);
                        },
                        children: "Odustani"
                    })
                ]
            })
        ]
    });
}
function DodavanjeNoveBoje({ dodajNovu  }) {
    const { setModalOpen  } = (0,ContextProvider/* useStateContext */.F)();
    const { 0: boja , 1: setBoja  } = (0,external_react_.useState)("#00ff00");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "3rem"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    flex: 1,
                    width: "100%",
                    height: "100%",
                    overflow: "hidden",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            flex: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_color_.ChromePicker, {
                            color: boja,
                            onChangeComplete: (color)=>setBoja(color.hex),
                            onChange: (color)=>setBoja(color.hex)
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            width: 150,
                            height: 50,
                            margin: 0,
                            position: "relative",
                            background: boja,
                            border: "1px solid black",
                            borderRadius: 15
                        }
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "1.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            dodajNovu(boja);
                            setModalOpen(false);
                        },
                        children: "Odaberi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setModalOpen(false);
                        },
                        children: "Odustani"
                    })
                ]
            })
        ]
    });
}
function DodavanjeNovogDodatka({ dodajNov  }) {
    const { setModalOpen  } = (0,ContextProvider/* useStateContext */.F)();
    const { 0: text , 1: setText  } = (0,external_react_.useState)("");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "3rem"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    flex: 1,
                    width: "100%",
                    height: "100%",
                    overflow: "hidden",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (form_module_default()).form_column,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (form_module_default()).form_label,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "dodatak",
                                children: "Dodatak *"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            id: "dodatak",
                            type: "text",
                            className: (form_module_default()).form_textarea,
                            name: "dodatak",
                            value: text,
                            onChange: (e)=>setText(e.target.value)
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "1.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            dodajNov(text);
                            setModalOpen(false);
                        },
                        children: "Odaberi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setModalOpen(false);
                        },
                        children: "Odustani"
                    })
                ]
            })
        ]
    });
}
function DodajSlike({ dodajNovu , odaberiPostojecu , multiple , slike  }) {
    const { 0: anchorEl , 1: setAnchorEl  } = (0,external_react_.useState)(null);
    const { setModalOpen , setModalChildren  } = (0,ContextProvider/* useStateContext */.F)();
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    function onDodajNovo() {
        setModalChildren(/*#__PURE__*/ jsx_runtime_.jsx(DodavanjeNoveSlike, {
            dodajNovu: dodajNovu
        }));
        setModalOpen(true);
        handleClose();
    }
    function onOdaberiPostojece() {
        setModalChildren(/*#__PURE__*/ jsx_runtime_.jsx(OdabirPostojeceSlike, {
            multiple: multiple,
            slike: slike,
            odaberiPostojecu: odaberiPostojecu
        }));
        setModalOpen(true);
        handleClose();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DodajButton, {
                onClick: handleClick,
                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlinePlus, {
                    color: "black",
                    size: 25
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                style: {
                    zIndex: 9999
                },
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                        onClick: onDodajNovo,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(md_.MdFileUpload, {
                                    color: "black",
                                    size: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: "Dodaj novu sliku"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                        onClick: onOdaberiPostojece,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsImage, {
                                    color: "black",
                                    size: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: "Odaberi postoje\u0107u sliku"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function DodajBoje({ dodajNovu , odaberiPostojecu , boje  }) {
    const { 0: anchorEl , 1: setAnchorEl  } = (0,external_react_.useState)(null);
    const { setModalOpen , setModalChildren  } = (0,ContextProvider/* useStateContext */.F)();
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    function onDodajNovo() {
        setModalChildren(/*#__PURE__*/ jsx_runtime_.jsx(DodavanjeNoveBoje, {
            dodajNovu: dodajNovu
        }));
        setModalOpen(true);
        handleClose();
    }
    function onOdaberiPostojece() {
        setModalChildren(/*#__PURE__*/ jsx_runtime_.jsx(OdabirPostojeceBoje, {
            boje: boje,
            odaberiPostojecu: odaberiPostojecu
        }));
        setModalOpen(true);
        handleClose();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DodajButton, {
                onClick: handleClick,
                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlinePlus, {
                    color: "black",
                    size: 25
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                style: {
                    zIndex: 9999
                },
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                        onClick: onDodajNovo,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(io_.IoMdColorFilter, {
                                    color: "black",
                                    size: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: "Dodaj novu boju"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                        onClick: onOdaberiPostojece,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(io_.IoMdColorPalette, {
                                    color: "black",
                                    size: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: "Odaberi postoje\u0107u boju"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function DodajDodatke({ dodajNov , odaberiPostojeci , dodaci  }) {
    const { 0: anchorEl , 1: setAnchorEl  } = (0,external_react_.useState)(null);
    const { setModalOpen , setModalChildren  } = (0,ContextProvider/* useStateContext */.F)();
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    function onDodajNov() {
        setModalChildren(/*#__PURE__*/ jsx_runtime_.jsx(DodavanjeNovogDodatka, {
            dodajNov: dodajNov
        }));
        setModalOpen(true);
        handleClose();
    }
    function onOdaberiPostojeci() {
        setModalChildren(/*#__PURE__*/ jsx_runtime_.jsx(OdabirPostojecegDodatka, {
            dodaci: dodaci,
            odaberiPostojeci: odaberiPostojeci
        }));
        setModalOpen(true);
        handleClose();
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DodajButton, {
                onClick: handleClick,
                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlinePlus, {
                    color: "black",
                    size: 25
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                style: {
                    zIndex: 9999
                },
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                        onClick: onDodajNov,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlinePlus, {
                                    color: "black",
                                    size: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: "Dodaj nov dodatak"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                        onClick: onOdaberiPostojeci,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineFileAdd, {
                                    color: "black",
                                    size: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: "Odaberi postoje\u0107 dodatak"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function DodajButton({ style , ...props }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            cursor: "pointer",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: 0,
            width: 40,
            height: 40,
            borderRadius: "50%",
            background: "white",
            border: "1px solid black",
            ...style
        },
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlinePlus, {
            color: "black",
            size: 25
        })
    });
}

// EXTERNAL MODULE: ./components/ProductCard/ProductCard.module.css
var ProductCard_module = __webpack_require__(6606);
var ProductCard_module_default = /*#__PURE__*/__webpack_require__.n(ProductCard_module);
// EXTERNAL MODULE: external "@mui/material/Tooltip"
var Tooltip_ = __webpack_require__(7229);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip_);
;// CONCATENATED MODULE: ./components/ProductCard/ProductCard.jsx

/* eslint-disable @next/next/no-img-element */ 





const ProductCard_IMAGE_HOST = "https://thereptilehouse.rs";
// const IMAGE_HOST = "http://localhost:10000"
function ProductCard(props) {
    const { openDeleteDialog , setLoader , createNotification , notificationTypes  } = (0,ContextProvider/* useStateContext */.F)();
    async function deleteProduct() {
        try {
            setLoader(true);
            const res = await fetch(`/api/${props.category}/${props.id}`, {
                method: "DELETE"
            });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message);
            props.refresh();
            createNotification({
                type: notificationTypes.SUCCESS,
                message: `Uspešno obrisan '${props.naziv}'`
            });
        } catch (error) {
            console.error(error);
            createNotification({
                type: notificationTypes.ERROR,
                message: error.message
            });
            setLoader(false);
        }
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (ProductCard_module_default()).product_card,
        style: props.style ?? {},
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (ProductCard_module_default()).product_card_image,
                style: {
                    cursor: "pointer"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    target: "_blank",
                    rel: "noreferrer",
                    href: `${ProductCard_IMAGE_HOST}/${props.category}/${props.id}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: `${ProductCard_IMAGE_HOST}${props.thumbnail}`,
                        alt: props.naziv
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (ProductCard_module_default()).product_card_content,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        target: "_blank",
                        rel: "noreferrer",
                        href: `${ProductCard_IMAGE_HOST}/${props.category}/${props.id}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            style: {
                                cursor: "pointer"
                            },
                            children: props.naziv
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (ProductCard_module_default()).product_card_content_row,
                        style: {
                            gap: "1rem"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                enterTouchDelay: 0,
                                arrow: true,
                                title: "Izmeni",
                                PopperProps: {
                                    style: {
                                        zIndex: 99999
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        width: "100%"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: `/${props.category}/${props.id}`,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                            style: {
                                                // borderRadius: "50%",
                                                // width: 40,
                                                // height: 40,
                                                // padding: 0,
                                                width: "100%",
                                                padding: "0.5rem",
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(md_.MdEdit, {
                                                color: "white",
                                                size: 25
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                enterTouchDelay: 0,
                                arrow: true,
                                title: "Obri\u0161i",
                                PopperProps: {
                                    style: {
                                        zIndex: 99999
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        width: "100%"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                                        style: {
                                            // borderRadius: "50%",
                                            // width: 40,
                                            // height: 40,
                                            // padding: 0,
                                            width: "100%",
                                            padding: "0.5rem",
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center"
                                        },
                                        onClick: ()=>openDeleteDialog({
                                                naziv: props.naziv,
                                                onYes: deleteProduct
                                            }),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(md_.MdDeleteForever, {
                                                color: "white",
                                                size: 25
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const ProductCard_ProductCard = (ProductCard);

;// CONCATENATED MODULE: ./components/ProductList/ProductList.jsx


function ProductList({ data , category , refresh  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            display: "flex",
            flexWrap: "wrap",
            gap: "2rem",
            justifyContent: "center",
            alignItems: "center"
        },
        children: data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(ProductCard_ProductCard, {
                refresh: refresh,
                ...item,
                category: category
            }, item.id))
    });
}
/* harmony default export */ const ProductList_ProductList = (ProductList);

// EXTERNAL MODULE: external "@mui/material/Dialog"
var Dialog_ = __webpack_require__(8611);
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog_);
// EXTERNAL MODULE: external "@mui/material/DialogActions"
var DialogActions_ = __webpack_require__(9404);
var DialogActions_default = /*#__PURE__*/__webpack_require__.n(DialogActions_);
// EXTERNAL MODULE: external "@mui/material/DialogContent"
var DialogContent_ = __webpack_require__(1094);
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent_);
// EXTERNAL MODULE: external "@mui/material/DialogContentText"
var DialogContentText_ = __webpack_require__(2268);
var DialogContentText_default = /*#__PURE__*/__webpack_require__.n(DialogContentText_);
// EXTERNAL MODULE: external "@mui/material/DialogTitle"
var DialogTitle_ = __webpack_require__(2468);
var DialogTitle_default = /*#__PURE__*/__webpack_require__.n(DialogTitle_);
// EXTERNAL MODULE: external "@mui/material/Slide"
var Slide_ = __webpack_require__(6080);
;// CONCATENATED MODULE: ./components/DeleteDialog/DeleteDialog.jsx









const Transition = /*#__PURE__*/ (/* unused pure expression or super */ null && (forwardRef(function Transition(props, ref) {
    return /*#__PURE__*/ _jsx(Slide, {
        direction: "up",
        ref: ref,
        ...props
    });
})));
function DeleteDialog({ naziv , onYes , open , setOpen  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dialog_default()), {
        open: open,
        style: {
            zIndex: 9999999
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((DialogTitle_default()), {
                children: "Upozorenje!"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((DialogContent_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((DialogContentText_default()), {
                    children: `Da li ste sigurni da želite trajno da obrišete '${naziv}'?`
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((DialogActions_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            setOpen(false);
                        },
                        autoFocus: true,
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        children: "NE"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            onYes?.();
                            setOpen(false);
                        },
                        children: "DA"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const DeleteDialog_DeleteDialog = (DeleteDialog);

// EXTERNAL MODULE: ./components/DragDropFile/DragDropFile.module.css
var DragDropFile_module = __webpack_require__(2681);
var DragDropFile_module_default = /*#__PURE__*/__webpack_require__.n(DragDropFile_module);
;// CONCATENATED MODULE: ./components/DragDropFile/DragDropFile.jsx



function DragDropFile({ inputRef  }) {
    // drag state
    const [dragActive, setDragActive] = external_react_.useState(false);
    // handle drag events
    const handleDrag = function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };
    // triggers when file is dropped
    const handleDrop = function(e) {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);
        if (e.dataTransfer.files) {
            inputRef.current.files = e.dataTransfer.files;
        }
    };
    // triggers when file is selected with click
    const handleChange = function(e) {
        e.preventDefault();
    };
    // triggers the input when the button is clicked
    const onButtonClick = ()=>{
        inputRef.current.click();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: (DragDropFile_module_default())["form-file-upload"],
        onDragEnter: handleDrag,
        onSubmit: (e)=>e.preventDefault(),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ref: inputRef,
                type: "file",
                className: (DragDropFile_module_default())["input-file-upload"],
                multiple: true,
                onChange: handleChange
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "input-file-upload",
                className: `${(DragDropFile_module_default())["label-file-upload"]} ${dragActive ? "drag-active" : ""}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                padding: "1rem"
                            },
                            children: "Prevucite i otpustite svoje datoteke ovde ili"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (DragDropFile_module_default())["upload-button"],
                            onClick: onButtonClick,
                            children: "Otpremite datoteku"
                        })
                    ]
                })
            }),
            dragActive && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (DragDropFile_module_default())["drag-file-element"],
                onDragEnter: handleDrag,
                onDragLeave: handleDrag,
                onDragOver: handleDrag,
                onDrop: handleDrop
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/OnDoubleClickInput/OnDoubleClickInput.jsx



function OnDubleClickInput({ value , onConfirm , style , renderText , ...rest }) {
    const { 0: showInput , 1: setShowInput  } = (0,external_react_.useState)(false);
    const { 0: inputValue , 1: setInputValue  } = (0,external_react_.useState)(value);
    (0,external_react_.useEffect)(()=>{
        setInputValue(value);
    }, [
        value
    ]);
    return showInput ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            flex: 1,
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "0.5rem"
        },
        ...rest,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                value: inputValue,
                onChange: (e)=>setInputValue(e.target.value),
                style: {
                    flex: 1,
                    outline: "none",
                    border: "1px solid black",
                    borderRadius: "7.5px",
                    padding: "0.75rem"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "0.75rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        onClick: ()=>{
                            onConfirm(inputValue);
                            setShowInput(false);
                            setInputValue(value);
                        },
                        children: "Sa\u010Duvaj"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(GradientButton_GradientButton, {
                        style: {
                            background: "white",
                            color: "black"
                        },
                        className: "box-shadow",
                        onClick: ()=>{
                            setShowInput(false);
                            setInputValue(value);
                        },
                        children: "Odbaci"
                    })
                ]
            })
        ]
    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
        onClick: (e)=>{
            if (e.detail >= 2) setShowInput(true);
        },
        style: {
            ...style
        },
        ...rest,
        children: renderText ? renderText?.(value) : /*#__PURE__*/ jsx_runtime_.jsx("b", {
            children: value
        })
    });
}
/* harmony default export */ const OnDoubleClickInput = (OnDubleClickInput);

;// CONCATENATED MODULE: ./components/index.jsx





















/***/ }),

/***/ 7912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ContextProvider),
  "F": () => (/* binding */ useStateContext)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./utils/hooks/useWindowSize.js

function useWindowSize() {
    const { 0: windowSize , 1: setWindowSize  } = (0,external_react_.useState)({
        width: undefined,
        height: undefined
    });
    (0,external_react_.useEffect)(()=>{
        function handleResize() {
            setWindowSize({
                width: window.innerWidth,
                height: window.innerHeight
            });
        }
        window.addEventListener("resize", handleResize);
        handleResize();
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    return windowSize;
};

// EXTERNAL MODULE: external "react-notifications"
var external_react_notifications_ = __webpack_require__(5974);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/index.jsx + 20 modules
var components = __webpack_require__(7452);
;// CONCATENATED MODULE: ./context/ContextProvider.js






const StateContext = /*#__PURE__*/ (0,external_react_.createContext)();
function ContextProvider({ children  }) {
    const router = (0,router_.useRouter)();
    const windowSize = useWindowSize();
    const { 0: activeMenu , 1: setActiveMenu  } = (0,external_react_.useState)(true);
    const { 0: loader , 1: setLoader  } = (0,external_react_.useState)(false);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const { 0: korisnik , 1: setKorisnik  } = (0,external_react_.useState)(null);
    const { 0: navHeight , 1: setNavHeight  } = (0,external_react_.useState)(0);
    const { 0: deleteDialogOpen , 1: setDeleteDialogOpen  } = (0,external_react_.useState)(false);
    const { 0: deleteDialogNaziv , 1: setDeleteDialogNaziv  } = (0,external_react_.useState)("");
    const { 0: deleteDialogOnYes , 1: setDeleteDialogOnYes  } = (0,external_react_.useState)(null);
    const { 0: modalOpen , 1: setModalOpen  } = (0,external_react_.useState)(false);
    const { 0: modalChildren , 1: setModalChildren  } = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        setActiveMenu(windowSize.width > 900);
    }, [
        windowSize
    ]);
    (0,external_react_.useEffect)(()=>{
        (async ()=>{
            try {
                const res = await fetch("/api/showme");
                const json = await res.json();
                if (!json.ok) throw new Error(json.message);
                setKorisnik(json.korisnik);
            } catch (error) {
                console.error(error);
                router.replace("/login");
            } finally{
                setTimeout(()=>{
                    setLoading(false);
                }, 1.5 * 1000);
            }
        })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const notificationTypes = {
        INFO: "info",
        SUCCESS: "success",
        WARNING: "warning",
        ERROR: "error"
    };
    function openDeleteDialog({ naziv , onYes  }) {
        setDeleteDialogOnYes(()=>onYes);
        setDeleteDialogNaziv(naziv);
        setDeleteDialogOpen(true);
    }
    function createNotification(params) {
        const [message, title, timeout, callback, priority] = [
            params?.message ?? "",
            params?.title ?? "",
            params?.timeout ?? 5000,
            params?.callback ?? (()=>{}),
            params?.priority ?? false
        ];
        switch(params.type){
            case notificationTypes.INFO:
                external_react_notifications_.NotificationManager.info(message, title, timeout, callback, priority);
                break;
            case notificationTypes.SUCCESS:
                external_react_notifications_.NotificationManager.success(message, title, timeout, callback, priority);
                break;
            case notificationTypes.WARNING:
                external_react_notifications_.NotificationManager.warning(message, title, timeout, callback, priority);
                break;
            case notificationTypes.ERROR:
                external_react_notifications_.NotificationManager.error(message, title, timeout, callback, priority);
                break;
            default:
                console.error(`${params.type} is invalid type. Try one of following: ${Object.keys(notificationTypes).join(", ")}`);
                break;
        }
    }
    let render = loading ? /*#__PURE__*/ jsx_runtime_.jsx(components/* Loader */.aN, {
        show: true
    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Loader */.aN, {
                show: loader
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StateContext.Provider, {
        value: {
            windowSize,
            activeMenu,
            setActiveMenu,
            notificationTypes,
            createNotification,
            loader,
            setLoader,
            korisnik,
            setKorisnik,
            navHeight,
            setNavHeight,
            openDeleteDialog,
            setModalChildren,
            setModalOpen
        },
        children: [
            render,
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_notifications_.NotificationContainer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* DeleteDialog */.AN, {
                open: deleteDialogOpen,
                setOpen: setDeleteDialogOpen,
                onYes: deleteDialogOnYes,
                naziv: deleteDialogNaziv
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Modal */.u_, {
                show: modalOpen,
                children: modalChildren
            })
        ]
    });
};
function useStateContext() {
    return (0,external_react_.useContext)(StateContext);
}


/***/ })

};
;