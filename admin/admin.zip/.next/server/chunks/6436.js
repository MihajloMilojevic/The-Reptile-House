"use strict";
exports.id = 6436;
exports.ids = [6436];
exports.modules = {

/***/ 701:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(7063);
async function svePorudzbine() {
    let data = await mysql.query(`SELECT * FROM porudzbine_json`);
    await mysql.end();
    data = data.map((item)=>JSON.parse(item.json));
    return data;
}
async function jednaPorudzbina(id) {
    let data = await mysql.query(`SELECT * FROM porudzbine_json WHERE id = ?`, [
        id
    ]);
    await mysql.end();
    if (data.length === 0) return null;
    return JSON.parse(data[0].json);
}
async function promeniStatus(id, status) {
    const data = await mysql.query("UPDATE porudzbine SET status_id = (SELECT id FROM statusi WHERE naziv = ?) WHERE id = ?", [
        status,
        id
    ]);
    await mysql.end();
    return data;
}
async function promeniIdPosiljke(id, posiljka_id) {
    const data = await mysql.query("UPDATE porudzbine SET posiljka_id = ? WHERE id = ?", [
        posiljka_id,
        id
    ]);
    await mysql.end();
    return data;
}
module.exports = {
    svePorudzbine,
    jednaPorudzbina,
    promeniStatus,
    promeniIdPosiljke
};


/***/ }),

/***/ 7063:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(2261)({
    config: {
        host: process.env.MYSQL_HOST,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD,
        multipleStatements: true
    }
});
module.exports = mysql;


/***/ }),

/***/ 4949:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const jwt = __webpack_require__(9344);
const { UnauthenticatedError  } = __webpack_require__(9367);
const auth = async (req, res)=>{
    const token = req.cookies.token;
    if (!token) throw new UnauthenticatedError("Authentication error");
    try {
        const sadrzaj = jwt.verify(token, process.env.JWT_SECRET) // VERIFY TOKEN
        ;
        return sadrzaj;
    } catch (error) {
        throw new UnauthenticatedError("Authentication error");
    }
};
module.exports = auth;


/***/ })

};
;