"use strict";
exports.id = 3339;
exports.ids = [3339];
exports.modules = {

/***/ 8014:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const { StatusCodes  } = __webpack_require__(8010);
const CustomAPIError = __webpack_require__(9744);
class BadRequestError extends CustomAPIError {
    constructor(message){
        super(message);
        this.statusCode = StatusCodes.BAD_REQUEST;
    }
}
module.exports = BadRequestError;


/***/ }),

/***/ 9744:
/***/ ((module) => {


class CustomAPIError extends Error {
    constructor(message, statusCode){
        super(message);
        this.statusCode = statusCode;
    }
}
module.exports = CustomAPIError;


/***/ }),

/***/ 531:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const { StatusCodes  } = __webpack_require__(8010);
const CustomAPIError = __webpack_require__(9744);
class ForbiddenError extends CustomAPIError {
    constructor(message){
        super(message);
        this.statusCode = StatusCodes.FORBIDDEN;
    }
}
module.exports = ForbiddenError;


/***/ }),

/***/ 9367:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const CustomAPIError = __webpack_require__(9744);
const UnauthenticatedError = __webpack_require__(327);
const BadRequestError = __webpack_require__(8014);
const NotFoundError = __webpack_require__(6338);
const ForbiddenError = __webpack_require__(531);
module.exports = {
    CustomAPIError,
    UnauthenticatedError,
    BadRequestError,
    NotFoundError,
    ForbiddenError
};


/***/ }),

/***/ 6338:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const { StatusCodes  } = __webpack_require__(8010);
const CustomAPIError = __webpack_require__(9744);
class NotFoundError extends CustomAPIError {
    constructor(message){
        super(message);
        this.statusCode = StatusCodes.NOT_FOUND;
    }
}
module.exports = NotFoundError;


/***/ }),

/***/ 327:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const { StatusCodes  } = __webpack_require__(8010);
const CustomAPIError = __webpack_require__(9744);
class UnauthenticatedError extends CustomAPIError {
    constructor(message){
        super(message);
        this.statusCode = StatusCodes.UNAUTHORIZED;
    }
}
module.exports = UnauthenticatedError;


/***/ }),

/***/ 7099:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const { StatusCodes  } = __webpack_require__(8010);
module.exports = (err, req, res, next)=>{
    let error = {
        // set default
        statusCode: err.statusCode || StatusCodes.INTERNAL_SERVER_ERROR,
        msg: err.message || "Doslo je do greske. Probajte ponovo kasnije."
    };
    console.trace(err);
    return res.status(error.statusCode).json({
        ok: false,
        message: error.msg
    });
};


/***/ }),

/***/ 9044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ errorWrapper)
/* harmony export */ });
/* harmony import */ var _errorHandler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7099);
/* harmony import */ var _errorHandler__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_errorHandler__WEBPACK_IMPORTED_MODULE_0__);

function errorWrapper(cb) {
    return async function(req, res) {
        try {
            await cb(req, res);
        } catch (error) {
            _errorHandler__WEBPACK_IMPORTED_MODULE_0___default()(error, req, res);
        }
    };
};


/***/ })

};
;