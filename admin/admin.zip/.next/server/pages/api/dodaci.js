"use strict";
(() => {
var exports = {};
exports.id = 1655;
exports.ids = [1655];
exports.modules = {

/***/ 8010:
/***/ ((module) => {

module.exports = require("http-status-codes");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 1434:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(7063);
async function sviDodaci() {
    const sql = "SELECT * FROM dodaci";
    let data = await mysql.query(sql);
    await mysql.end();
    return data;
}
async function promeniDodatak(stariNaziv, noviNaziv) {
    const data = await mysql.query("UPDATE dodaci SET naziv = ? WHERE naziv = ?", [
        noviNaziv,
        stariNaziv
    ]);
    await mysql.end();
    return data;
}
async function obrisiDodatak(naziv) {
    const data = await mysql.query("DELETE FROM dodaci WHERE naziv = ?", [
        naziv
    ]);
    await mysql.end();
    return data;
}
module.exports = {
    sviDodaci,
    promeniDodatak,
    obrisiDodatak
};


/***/ }),

/***/ 7063:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(2261)({
    config: {
        host: process.env.MYSQL_HOST,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD,
        multipleStatements: true
    }
});
module.exports = mysql;


/***/ }),

/***/ 4949:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const jwt = __webpack_require__(9344);
const { UnauthenticatedError  } = __webpack_require__(9367);
const auth = async (req, res)=>{
    const token = req.cookies.token;
    if (!token) throw new UnauthenticatedError("Authentication error");
    try {
        const sadrzaj = jwt.verify(token, process.env.JWT_SECRET) // VERIFY TOKEN
        ;
        return sadrzaj;
    } catch (error) {
        throw new UnauthenticatedError("Authentication error");
    }
};
module.exports = auth;


/***/ }),

/***/ 511:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _middleware_errorWrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9044);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9367);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_errors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8010);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(http_status_codes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _database_controllers_dodaci__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1434);
/* harmony import */ var _database_controllers_dodaci__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_database_controllers_dodaci__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _middleware_authentication__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4949);
/* harmony import */ var _middleware_authentication__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_middleware_authentication__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
    onNoMatch: (0,_middleware_errorWrapper__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)((req, res)=>{
        throw new (_errors__WEBPACK_IMPORTED_MODULE_2___default().NotFoundError)(`${req.method} ${req.url} ne postoji`);
    })
});
handler.use(async (req, res, next)=>{
    await _middleware_authentication__WEBPACK_IMPORTED_MODULE_5___default()(req, res);
    next();
});
handler.get((0,_middleware_errorWrapper__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(async (req, res)=>{
    const data = await (0,_database_controllers_dodaci__WEBPACK_IMPORTED_MODULE_4__.sviDodaci)();
    res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.OK).json({
        ok: true,
        data
    });
}));
handler.patch((0,_middleware_errorWrapper__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(async (req, res)=>{
    const data = await (0,_database_controllers_dodaci__WEBPACK_IMPORTED_MODULE_4__.promeniDodatak)(req.body.stariNaziv, req.body.noviNaziv);
    res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.OK).json({
        ok: true,
        data
    });
}));
handler.delete((0,_middleware_errorWrapper__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(async (req, res)=>{
    const data = await (0,_database_controllers_dodaci__WEBPACK_IMPORTED_MODULE_4__.obrisiDodatak)(req.body.naziv);
    console.log(req.body);
    res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.OK).json({
        ok: true,
        data
    });
}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3339], () => (__webpack_exec__(511)));
module.exports = __webpack_exports__;

})();