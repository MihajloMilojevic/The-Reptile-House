(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 7646:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(2261)({
  config: {
    host: process.env.MYSQL_HOST,
    database: process.env.MYSQL_DATABASE,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    multipleStatements: true
  }
});

module.exports = mysql;

/***/ }),

/***/ 203:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(7646);

async function preporuceno() {
  const sql = "SELECT CASE k.naziv WHEN 'terarijumi' THEN json_terarijum(p.id) WHEN 'zivotinje' THEN json_zivotinja(p.id) ELSE json_hrana_i_oprema(p.id) END as json FROM proizvodi p JOIN kategorije k ON p.kategorija_id = k.id WHERE p.preporuceno IS TRUE ORDER BY p.kategorija_id, p.naziv;";
  let data = await mysql.query(sql);
  await mysql.end();
  data = data.map(item => JSON.parse(item.json));
  return data;
}

module.exports = preporuceno;

/***/ }),

/***/ 2748:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1072);
/* harmony import */ var _context_ContextProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(262);
/* harmony import */ var _styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6210);
/* harmony import */ var _styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3015);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _database_preporuceno__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(203);
/* harmony import */ var _database_preporuceno__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_database_preporuceno__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_5__, swiper_react__WEBPACK_IMPORTED_MODULE_6__]);
([swiper__WEBPACK_IMPORTED_MODULE_5__, swiper_react__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function Home(props) {
  const {
    windowSize
  } = (0,_context_ContextProvider__WEBPACK_IMPORTED_MODULE_3__/* .useStateContext */ .F)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("title", {
        children: "The Reptile House"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("meta", {
        name: "description",
        content: "The reptile house se bavi uzgojem i prodajom reptila i insekata, kao i izradom terarijuma za odgoj istih. Strogom selekcijom, pravilnim ukr\u0161tanjem i odgojem zdravih \u017Eivotinja, specifi\u010Dnih boja i gena, trudimo se teraristiku predstavimo u pravom svetlu."
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(Hero, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(Preporuceno, {
      data: props.preporuceno,
      widthPercent: 0.9
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("section", {
      className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().quote),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().quote_p),
        children: "Strogom selekcijom, pravilnim ukr\u0161tanjem i odgojem zdravih \u017Eivotinja, specifi\u010Dnih boja i gena, trudimo se teraristiku predstavimo u pravom svetlu."
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(PitanjeForma, {})]
  });
}
async function getStaticProps() {
  const prep = await _database_preporuceno__WEBPACK_IMPORTED_MODULE_8___default()();
  return {
    props: {
      preporuceno: prep
    },
    revalidate: 60
  };
}
const initialFormData = {
  ime: {
    value: "",
    error: ""
  },
  mejl: {
    value: "",
    error: ""
  },
  poruka: {
    value: "",
    error: ""
  }
};

function PitanjeForma() {
  const {
    createNotification,
    notificationTypes
  } = (0,_context_ContextProvider__WEBPACK_IMPORTED_MODULE_3__/* .useStateContext */ .F)();
  const {
    0: formData,
    1: setFormData
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialFormData);

  function handleChange(e) {
    setFormData(_objectSpread(_objectSpread({}, formData), {}, {
      [e.target.name]: _objectSpread(_objectSpread({}, formData[e.target.name]), {}, {
        value: e.target.value
      })
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    let hasError = false;

    let formDataCopy = _objectSpread({}, formData);

    if (!formDataCopy.ime.value) {
      formDataCopy.ime.error = "Morate uneti ime.";
      hasError = true;
    } else if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?0-9]+/.test(formDataCopy.ime.value)) {
      formDataCopy.ime.error = "Ime ne sme sadržati specijalne karaktere";
      hasError = true;
    } else {
      formDataCopy.ime.error = "";
    }

    if (!formDataCopy.mejl.value) {
      formDataCopy.mejl.error = "Morate uneti mejl.";
      hasError = true;
    } else if (!/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(formDataCopy.mejl.value)) {
      formDataCopy.mejl.error = "Neispravan format mejl adrese";
      hasError = true;
    } else {
      formDataCopy.mejl.error = "";
    }

    if (!formDataCopy.poruka.value) {
      formDataCopy.poruka.error = "Morate uneti poruku.";
      hasError = true;
    } else {
      formDataCopy.poruka.error = "";
    }

    if (hasError) {
      setFormData(formDataCopy);
      return;
    }

    try {
      const res = await fetch("/api/mail", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ime: formData.ime.value,
          mejl: formData.mejl.value,
          poruka: formData.poruka.value
        })
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.message);
      setFormData(initialFormData);
      createNotification({
        type: notificationTypes.SUCCESS,
        message: "Poruka uspešno poslata. Možete očekivati odgovor u narednih par dana."
      });
    } catch (error) {
      console.error(error);
      createNotification({
        type: notificationTypes.error,
        message: "Došlo je do greške. Pokušajte ponovo kasnije."
      });
    }
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("section", {
    className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_container),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .PageTitle */ .V1, {
      level: 3,
      style: {
        fontSize: 32
      },
      children: "Imate pitanja? Po\u0161aljite nam poruku"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
      className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form),
      onSubmit: handleSubmit,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_row),
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_column),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_label),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Ime *"
            }), formData.ime.error && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
              className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_label_error),
              children: formData.ime.error
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_input),
            name: "ime",
            value: formData.ime.value,
            onChange: handleChange
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_column),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_label),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Mejl *"
            }), formData.mejl.error && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
              className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_label_error),
              children: formData.mejl.error
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_input),
            name: "mejl",
            value: formData.mejl.value,
            onChange: handleChange
          })]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_row),
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_column),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_label),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Poruka *"
            }), formData.poruka.error && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
              className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_label_error),
              children: formData.poruka.error
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("textarea", {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_textarea),
            name: "poruka",
            value: formData.poruka.value,
            onChange: handleChange
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().form_row),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .GradientButton */ .OQ, {
          type: "submit",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            style: {
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: "1rem",
              paddingLeft: "1rem",
              paddingRight: "1rem"
            },
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiSend, {
              stroke: "#fff"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
              children: "Po\u0161alji"
            })]
          })
        })
      })]
    })]
  });
}

function Hero() {
  const {
    navHeight,
    windowSize
  } = (0,_context_ContextProvider__WEBPACK_IMPORTED_MODULE_3__/* .useStateContext */ .F)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("header", {
    className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero),
    style: {
      minHeight: `calc(100vh - ${navHeight}px)`
    },
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_text),
      style: _objectSpread({}, windowSize.width > 900 ? {
        minHeight: `calc(75vh - ${navHeight}px)`
      } : {}),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .PageTitle */ .V1, {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_text_title),
        children: "The Reptile House"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_text_p),
        children: "The Reptile House se bavi uzgojem i prodajom reptila i insekata, kao i izradom terarijuma za odgoj istih."
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
        href: "/terarijumi",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .GradientButton */ .OQ, {
            className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_text_button),
            children: "Pregledaj"
          })
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_image),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("img", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_image_blob),
        alt: "",
        src: "/home_blob.svg"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("img", {
        className: (_styles_homepage_module_css__WEBPACK_IMPORTED_MODULE_10___default().hero_image_image),
        alt: "",
        src: "/home_image.png"
      })]
    })]
  });
}

function Preporuceno({
  data,
  widthPercent
}) {
  const {
    windowSize
  } = (0,_context_ContextProvider__WEBPACK_IMPORTED_MODULE_3__/* .useStateContext */ .F)();
  const {
    0: containerWidth,
    1: setContainerWidth
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(windowSize.width * widthPercent);
  const {
    0: slidesPerView,
    1: setSlidesPerView
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    setContainerWidth(windowSize.width * widthPercent);
  }, [windowSize]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (containerWidth >= 2400) setSlidesPerView(7);else if (containerWidth >= 2000) setSlidesPerView(6);else if (containerWidth >= 1600) setSlidesPerView(5);else if (containerWidth >= 1250) setSlidesPerView(4);else if (containerWidth >= 950) setSlidesPerView(3);else if (containerWidth >= 600) setSlidesPerView(2);else setSlidesPerView(1);
  }, [containerWidth]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("section", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .PageTitle */ .V1, {
      level: 2,
      style: {
        fontSize: 32
      },
      children: "Preporu\u010Deno:"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
      style: {
        width: isNaN(containerWidth) ? "100%" : containerWidth,
        margin: "auto"
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__.Swiper, {
        modules: [swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation],
        loop: true,
        autoplay: {
          delay: 2000
        },
        slidesPerView: slidesPerView,
        navigation: true,
        children: data.map((item, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__.SwiperSlide, {
          style: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .ProductCard */ .Il, _objectSpread(_objectSpread({}, item), {}, {
            url: `/${item.kategorija}/${item.id}`,
            style: {
              margin: "1rem",
              width: 350
            }
          }))
        }, index))
      })
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6210:
/***/ ((module) => {

// Exports
module.exports = {
	"hero": "homepage_hero__gDNYT",
	"hero_text": "homepage_hero_text___qb0q",
	"hero_text_title": "homepage_hero_text_title__c3mBf",
	"hero_text_p": "homepage_hero_text_p__iPGFx",
	"hero_text_button": "homepage_hero_text_button__rLTro",
	"hero_image": "homepage_hero_image__EsOPD",
	"hero_image_image": "homepage_hero_image_image__1A_DI",
	"hero_image_blob": "homepage_hero_image_blob__oarKo",
	"quote": "homepage_quote__ukpeG",
	"quote_p": "homepage_quote_p__vDETo",
	"form_container": "homepage_form_container__AC3Fx",
	"form": "homepage_form__T46WX",
	"form_row": "homepage_form_row__c19VU",
	"form_column": "homepage_form_column___kAT4",
	"form_label": "homepage_form_label__4DFYN",
	"form_label_error": "homepage_form_label_error__m0ciT",
	"form_input": "homepage_form_input__3YRZa",
	"form_textarea": "homepage_form_textarea__ytqZD"
};


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 5974:
/***/ ((module) => {

"use strict";
module.exports = require("react-notifications");

/***/ }),

/***/ 8176:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2261:
/***/ ((module) => {

"use strict";
module.exports = require("serverless-mysql");

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [383,664,264], () => (__webpack_exec__(2748)));
module.exports = __webpack_exports__;

})();