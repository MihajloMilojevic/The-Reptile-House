(() => {
var exports = {};
exports.id = 478;
exports.ids = [478];
exports.modules = {

/***/ 8010:
/***/ ((module) => {

"use strict";
module.exports = require("http-status-codes");

/***/ }),

/***/ 2261:
/***/ ((module) => {

"use strict";
module.exports = require("serverless-mysql");

/***/ }),

/***/ 7151:
/***/ ((module) => {

"use strict";
module.exports = require("uid");

/***/ }),

/***/ 5616:
/***/ ((module) => {

"use strict";
module.exports = import("next-connect");;

/***/ }),

/***/ 366:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(2261)({
  config: {
    host: process.env.MYSQL_HOST,
    database: process.env.MYSQL_DATABASE,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    multipleStatements: true
  }
});

module.exports = mysql;

/***/ }),

/***/ 7822:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const mysql = __webpack_require__(366);

const {
  uid
} = __webpack_require__(7151);

function dodajProizvodSQL({
  proizvod_id,
  porudzbina_id,
  kolicina,
  boja,
  natpis
}) {
  return [`CALL dodaj_proizvod_porudzbina(?, ?, ?, ?, ?); `, [proizvod_id, porudzbina_id, kolicina, boja ?? "", natpis ?? ""]];
}

function dodajSveProizvode(proizvodi, id_porudzbine) {
  let sqlAll = "";
  let paramsAll = [];
  proizvodi.forEach(proizvod => {
    const [sql, params] = dodajProizvodSQL(_objectSpread(_objectSpread({}, proizvod), {}, {
      porudzbina_id: id_porudzbine
    }));
    sqlAll += sql;
    paramsAll = [...paramsAll, ...params];
  });
  console.log({
    sqlAll,
    paramsAll
  });
  return [sqlAll, paramsAll];
}

async function poruci({
  ime,
  prezime,
  mejl,
  adresa,
  telefon,
  proizvodi
}) {
  const id = uid(20);
  const [dodajSql, dodajParams] = dodajSveProizvode(proizvodi, id);
  let data = await mysql.query("INSERT INTO porudzbine(id, ime, prezime, mejl, adresa, telefon) \n" + "VALUES(?, ?, ?, ?, ?, ?); \n" + dodajSql, [id, ime, prezime, mejl, adresa, telefon, ...dodajParams]);
  await mysql.end();
  return data;
}

module.exports = poruci;

/***/ }),

/***/ 4087:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8010);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status_codes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database_porudzbine__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7822);
/* harmony import */ var _database_porudzbine__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database_porudzbine__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
  onError: (err, req, res, next) => {
    console.error(err.stack);
    res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().INTERNAL_SERVER_ERROR)).json({
      ok: false,
      message: `Došlo je do greške`,
      error: err
    });
  },
  onNoMatch: (req, res) => {
    res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().NOT_FOUND)).json({
      ok: false,
      message: `${req.method} ${req.url} ne postoji`
    });
  }
});
handler.post(async (req, res) => {
  const data = await _database_porudzbine__WEBPACK_IMPORTED_MODULE_2___default()(req.body);
  res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().OK)).json({
    ok: true,
    data
  });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4087));
module.exports = __webpack_exports__;

})();