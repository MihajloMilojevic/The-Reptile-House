"use strict";
(() => {
var exports = {};
exports.id = 70;
exports.ids = [70];
exports.modules = {

/***/ 8010:
/***/ ((module) => {

module.exports = require("http-status-codes");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 2420:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8010);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status_codes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5184);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nodemailer__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
  onError: (err, req, res, next) => {
    console.error(err.stack);
    res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().INTERNAL_SERVER_ERROR)).json({
      ok: false,
      message: `Došlo je do greške`,
      error: err
    });
  },
  onNoMatch: (req, res) => {
    res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().NOT_FOUND)).json({
      ok: false,
      message: `${req.method} ${req.url} ne postoji`
    });
  }
});
handler.post(async (req, res) => {
  const {
    mejl,
    ime,
    poruka
  } = req.body;
  if (!mejl || !ime || !poruka) return res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().BAD_REQUEST)).json({
    ok: false,
    message: "Ime, mejl i poruka su obavezni"
  });
  const transporter = nodemailer__WEBPACK_IMPORTED_MODULE_2___default().createTransport({
    host: "thereptilehouse.rs",
    port: 465,
    secure: true,
    // true for 465, false for other ports
    auth: {
      user: process.env.MAIL_USER,
      // generated ethereal user
      pass: process.env.MAIL_PASSWORD // generated ethereal password

    }
  });
  const data = await transporter.sendMail({
    from: `The reptile house <${process.env.MAIL_USER}>`,
    // sender address
    to: "thereptilehouse.info@gmail.com",
    // list of receivers
    subject: `Pitanje sa sajta - ${ime}`,
    // Subject line
    text: `${mejl}\n ${poruka}`,
    // plain text body
    html: `	<p><b>Ime</b>: ${ime}</p>
				<p><b>Mejl</b>: <a href="mailto:${mejl}">${mejl}</a></p>
				<p><b>Poruka</b>: ${poruka}</p>		
		` // html body

  });
  res.status((http_status_codes__WEBPACK_IMPORTED_MODULE_1___default().CREATED)).json({
    ok: true,
    data
  });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2420));
module.exports = __webpack_exports__;

})();