(() => {
var exports = {};
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 2261:
/***/ ((module) => {

"use strict";
module.exports = require("serverless-mysql");

/***/ }),

/***/ 5616:
/***/ ((module) => {

"use strict";
module.exports = import("next-connect");;

/***/ }),

/***/ 5267:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(366);

async function doplate() {
  const sql = "SELECT * FROM doplate";
  let data = await mysql.query(sql);
  await mysql.end();
  let obj = {};
  data.forEach(element => {
    obj[element.naziv] = element.cena;
  });
  return obj;
}

module.exports = doplate;

/***/ }),

/***/ 366:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(2261)({
  config: {
    host: process.env.MYSQL_HOST,
    database: process.env.MYSQL_DATABASE,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    multipleStatements: true
  }
});

module.exports = mysql;

/***/ }),

/***/ 8801:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(366);
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_database__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _database_doplate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5267);
/* harmony import */ var _database_doplate__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_database_doplate__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
  onError: (err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
      ok: false,
      message: `Došlo je do greške`,
      error: err
    });
  },
  onNoMatch: (req, res) => {
    res.status(404).json({
      ok: false,
      message: `${req.method} ${req.url} ne postoji`
    });
  }
});
handler.get(async (req, res) => {
  // const data = await mysql.query("INSERT INTO porudzbine(id, ime, prezime, mejl, adresa, telefon) VALUES('8575a7ede0b3e4a3e361', 'Mihajlo', 'Milojević', 'milojevicm374@gmail.com', '8. mart 70', '0649781191'); CALL dodaj_proizvod_porudzbina('6e9nl6xljm6f', '8575a7ede0b3e4a3e361', '5', '#000000', '');  CALL dodaj_proizvod_porudzbina('6e9nl6xljm6f', '8575a7ede0b3e4a3e361', '1', '#ff0000', '');  CALL dodaj_proizvod_porudzbina('6e9nl6xljm6f', '8575a7ede0b3e4a3e361', '2', '#000000', 'Samo natpis');  CALL dodaj_proizvod_porudzbina('6e9nl6xljm6f', '8575a7ede0b3e4a3e361', '3', '#00ff00', 'Natpis i boja');")
  res.status(200).json({
    ok: true
  });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8801));
module.exports = __webpack_exports__;

})();