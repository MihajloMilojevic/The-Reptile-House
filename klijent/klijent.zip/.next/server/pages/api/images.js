(() => {
var exports = {};
exports.id = 899;
exports.ids = [899];
exports.modules = {

/***/ 3582:
/***/ ((module) => {

"use strict";
module.exports = require("cors");

/***/ }),

/***/ 6674:
/***/ ((module) => {

"use strict";
module.exports = require("express-fileupload");

/***/ }),

/***/ 8010:
/***/ ((module) => {

"use strict";
module.exports = require("http-status-codes");

/***/ }),

/***/ 2261:
/***/ ((module) => {

"use strict";
module.exports = require("serverless-mysql");

/***/ }),

/***/ 5616:
/***/ ((module) => {

"use strict";
module.exports = import("next-connect");;

/***/ }),

/***/ 5182:
/***/ ((module) => {

"use strict";
module.exports = import("uid");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 366:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(2261)({
  config: {
    host: process.env.MYSQL_HOST,
    database: process.env.MYSQL_DATABASE,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    multipleStatements: true
  }
});

module.exports = mysql;

/***/ }),

/***/ 6811:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(366);

const fs = __webpack_require__(7147);

const path = __webpack_require__(1017);

async function kreirajSliku(src, kategorija) {
  const sql = `INSERT INTO slike(src, kategorija_id) VALUES ('${src}', (SELECT id FROM kategorije WHERE naziv = '${kategorija}'))`;
  const data = await mysql.query(sql);
  await mysql.end();
  return data;
}

async function obrisiSliku(src) {
  console.log("obrisiSliku start");
  const imagePath = path.join(__dirname, "../../../../public", src);
  const sql = `DELETE FROM slike WHERE src = '${src}'`;
  const data = await mysql.query(sql);
  console.log({
    data,
    type: typeof data
  });
  await mysql.end();
  fs.unlinkSync(imagePath);
  console.log("slika obrisana iz public foldera");
  console.log("slika obrisana iz baze");
  return data;
}

module.exports = {
  kreirajSliku,
  obrisiSliku
};

/***/ }),

/***/ 1854:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var uid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5182);
/* harmony import */ var express_fileupload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6674);
/* harmony import */ var express_fileupload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_fileupload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8010);
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(http_status_codes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _database_slike__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6811);
/* harmony import */ var _database_slike__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_database_slike__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3582);
/* harmony import */ var cors__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(cors__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__, uid__WEBPACK_IMPORTED_MODULE_1__]);
([next_connect__WEBPACK_IMPORTED_MODULE_0__, uid__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
  onError: (err, req, res, next) => {
    console.error(err.stack);
    res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.INTERNAL_SERVER_ERROR).json({
      ok: false,
      message: err.message || "Došlo je do greške. Probajte ponovo kasnije."
    });
  },
  onNoMatch: (req, res) => {
    res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.NOT_FOUND).json({
      ok: false,
      message: `${req.method} ${req.url} ne postoji`
    });
  }
});
handler.use(cors__WEBPACK_IMPORTED_MODULE_6___default()({
  // "origin": ["*"],
  // "origin": ["http://localhost:8000"],
  "methods": "GET, POST, PUT, DELETE"
}));
handler.use(express_fileupload__WEBPACK_IMPORTED_MODULE_2___default()());
handler.post(async (req, res) => {
  const ids = [];

  for (const key in req.files) {
    const image = req.files[key];
    const splitImageName = image.name.split(".");
    const imageExtension = splitImageName[splitImageName.length - 1];
    const imageName = (0,uid__WEBPACK_IMPORTED_MODULE_1__.uid)(20) + "." + imageExtension;
    const imagePath = path__WEBPACK_IMPORTED_MODULE_4___default().join(__dirname, "../../../../public/images", imageName);
    await image.mv(imagePath);
    const data = await (0,_database_slike__WEBPACK_IMPORTED_MODULE_5__.kreirajSliku)(`/images/${imageName}`, req.body.kategorija);
    ids.push(data.insertId);
  }

  res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.CREATED).json({
    ok: true,
    ids
  });
});
handler.delete(async (req, res) => {
  console.log("start");
  const data = await (0,_database_slike__WEBPACK_IMPORTED_MODULE_5__.obrisiSliku)(req.body.src);
  console.log("return");
  res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.OK).json({
    ok: true,
    data
  });
});
handler.options(async (req, res) => {
  res.status(http_status_codes__WEBPACK_IMPORTED_MODULE_3__.StatusCodes.OK).end();
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
const config = {
  api: {
    bodyParser: false
  }
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1854));
module.exports = __webpack_exports__;

})();