(() => {
var exports = {};
exports.id = 526;
exports.ids = [526];
exports.modules = {

/***/ 5492:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(7646);

async function doplate() {
  const sql = "SELECT * FROM doplate";
  let data = await mysql.query(sql);
  await mysql.end();
  let obj = {};
  data.forEach(element => {
    obj[element.naziv] = element.cena;
  });
  return obj;
}

module.exports = doplate;

/***/ }),

/***/ 7646:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(2261)({
  config: {
    host: process.env.MYSQL_HOST,
    database: process.env.MYSQL_DATABASE,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    multipleStatements: true
  }
});

module.exports = mysql;

/***/ }),

/***/ 5185:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mysql = __webpack_require__(7646);

async function sviTerarijumi() {
  let data = await mysql.query(`SELECT * FROM terarijumi`);
  await mysql.end();
  data = data.map(item => JSON.parse(item.json));
  return data;
}

async function jedanTerarijum(id) {
  let data = await mysql.query(`SELECT * FROM terarijumi WHERE id = '${id}'`);
  await mysql.end();
  if (data.length === 0) return null;
  return JSON.parse(data[0].json);
}

module.exports = {
  sviTerarijumi,
  jedanTerarijum
};

/***/ }),

/***/ 7981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: ./components/index.jsx + 14 modules
var components = __webpack_require__(1072);
// EXTERNAL MODULE: ./context/ContextProvider.js + 1 modules
var ContextProvider = __webpack_require__(262);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: external "@mui/material/Switch"
const Switch_namespaceObject = require("@mui/material/Switch");
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/FormControlLabel"
const FormControlLabel_namespaceObject = require("@mui/material/FormControlLabel");
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Tooltip"
const Tooltip_namespaceObject = require("@mui/material/Tooltip");
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip_namespaceObject);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./database/doplate.js
var doplate = __webpack_require__(5492);
var doplate_default = /*#__PURE__*/__webpack_require__.n(doplate);
// EXTERNAL MODULE: ./database/terarijumi.js
var terarijumi = __webpack_require__(5185);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./pages/terarijumi/[id].jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















function Dimenzije({
  duzina,
  sirina,
  visina
}) {
  const {
    windowSize
  } = (0,ContextProvider/* useStateContext */.F)();

  function Item({
    text,
    value
  }) {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "center"
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(components/* Kvadrat */.$x, {
        style: {
          marginRight: "1rem"
        }
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        style: {
          width: 100
        },
        children: text
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
        style: {
          width: 100
        },
        children: [value, "mm"]
      })]
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
      children: "Dimenzije:"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-start",
        alignItems: "flex-start",
        gap: "0.5rem",
        marginLeft: windowSize.width <= 900 ? windowSize.width <= 500 ? "1rem" : "1.5rem" : "2rem"
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(Item, {
        text: "Du\u017Eina:",
        value: duzina
      }), /*#__PURE__*/jsx_runtime_.jsx(Item, {
        text: "\u0160irina:",
        value: sirina
      }), /*#__PURE__*/jsx_runtime_.jsx(Item, {
        text: "Visina:",
        value: visina
      })]
    })]
  });
}

function Dodaci({
  dodaci
}) {
  const {
    windowSize
  } = (0,ContextProvider/* useStateContext */.F)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
      children: "Dodaci:"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-start",
        alignItems: "flex-start",
        gap: "0.5rem",
        marginLeft: windowSize.width <= 900 ? windowSize.width <= 500 ? "1rem" : "1.5rem" : "2rem"
      },
      children: dodaci.map((item, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        style: {
          display: "flex",
          justifyContent: "flex-start",
          alignItems: "center",
          gap: "1rem"
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(components/* Kvadrat */.$x, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
          children: item
        })]
      }, index))
    })]
  });
}

function Boje({
  current,
  values,
  onChange
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
      width: "0",
      height: "0",
      style: {
        visibility: "hidden"
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("linearGradient", {
        id: "blue-gradient",
        x1: "100%",
        y1: "100%",
        x2: "0%",
        y2: "0%",
        children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
          stopColor: "#0283E9",
          offset: "-18.13%"
        }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
          stopColor: "#FC01CA",
          offset: "120.27%"
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      style: {
        display: "flex",
        justifyContent: "space-around",
        alignItems: "center",
        gap: "1rem",
        marginBottom: "1rem",
        width: "100%"
      },
      children: values.map((boja, index) => /*#__PURE__*/jsx_runtime_.jsx("div", {
        onClick: () => onChange(index),
        style: {
          background: boja.hex,
          borderRadius: "50%",
          width: 40,
          height: 40,
          border: "1px solid black",
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        },
        children: index === current && /*#__PURE__*/jsx_runtime_.jsx(bs_.BsCheckLg, {
          size: 20,
          style: {
            fill: "url(#blue-gradient)"
          }
        })
      }, index))
    })]
  });
}

function Cutomization({
  bojaValue,
  bojaChange,
  natpisValue,
  natpisChange,
  doplateCene
}) {
  const {
    windowSize
  } = (0,ContextProvider/* useStateContext */.F)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        display: "flex",
        justifyContent: "flex-start",
        alignItems: windowSize.width <= 1000 && windowSize.width >= 900 || windowSize.width <= 400 ? "flex-start" : "center",
        gap: windowSize.width <= 1000 && windowSize.width >= 900 || windowSize.width <= 400 ? "1rem" : "2rem",
        margin: "1rem",
        flexDirection: windowSize.width <= 1000 && windowSize.width >= 900 || windowSize.width <= 400 ? "column" : "row"
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx((Tooltip_default()), {
        enterTouchDelay: 0,
        arrow: true,
        title: "Ukoliko se odlu\u010Dite za prilago\u0111enu boju, nakon poru\u010Divanja neko \u0107e Vam se javiti oko mogu\u0107nosti prilago\u0111avanja.",
        children: /*#__PURE__*/jsx_runtime_.jsx((FormControlLabel_default()), {
          control: /*#__PURE__*/jsx_runtime_.jsx((Switch_default()), {
            checked: bojaValue.checked,
            onChange: e => bojaChange(_objectSpread(_objectSpread({}, bojaValue), {}, {
              checked: e.target.checked
            })),
            color: "secondary"
          }),
          label: `Prilagodjena boja - ${doplateCene.boja}din.`,
          labelPlacement: "end"
        })
      }), bojaValue.checked && /*#__PURE__*/jsx_runtime_.jsx("div", {
        style: windowSize.width <= 1000 && windowSize.width >= 900 || windowSize.width <= 400 ? {
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          margin: 0
        } : {},
        children: /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "color",
          value: bojaValue.hex,
          onChange: e => bojaChange(_objectSpread(_objectSpread({}, bojaValue), {}, {
            hex: e.target.value
          }))
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        display: "flex",
        justifyContent: "flex-start",
        alignItems: windowSize.width <= 1300 && windowSize.width >= 900 || windowSize.width <= 700 ? "flex-start" : "center",
        gap: windowSize.width <= 1300 && windowSize.width >= 900 || windowSize.width <= 700 ? "1rem" : "2rem",
        margin: "1rem",
        flexDirection: windowSize.width <= 1300 && windowSize.width >= 900 || windowSize.width <= 700 ? "column" : "row"
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx((Tooltip_default()), {
        enterTouchDelay: 0,
        arrow: true,
        title: "Ukoliko se odlu\u010Dite za prilago\u0111en natpis, nakon poru\u010Divanja neko \u0107e Vam se javiti oko mogu\u0107nosti prilago\u0111avanja.",
        children: /*#__PURE__*/jsx_runtime_.jsx((FormControlLabel_default()), {
          control: /*#__PURE__*/jsx_runtime_.jsx((Switch_default()), {
            checked: natpisValue.checked,
            onChange: e => natpisChange(_objectSpread(_objectSpread({}, natpisValue), {}, {
              checked: e.target.checked
            })),
            color: "secondary"
          }),
          label: `Prilagodjen natpis - ${doplateCene.natpis}din.`,
          labelPlacement: "end",
          style: {
            minWidth: "fit-content"
          }
        })
      }), natpisValue.checked && /*#__PURE__*/jsx_runtime_.jsx("input", {
        type: "text",
        value: natpisValue.natpis,
        onChange: e => natpisChange(_objectSpread(_objectSpread({}, natpisValue), {}, {
          natpis: e.target.value
        })),
        style: {
          width: "100%",
          outline: "none",
          border: "1px solid black",
          borderRadius: 15,
          padding: "1rem 1rem"
        }
      })]
    })]
  });
}

function Terarijum(params) {
  const {
    0: kolicina,
    1: setKolicna
  } = (0,external_react_.useState)(1);
  const {
    0: bojaIndex,
    1: setBojaIndex
  } = (0,external_react_.useState)(0);
  const {
    0: customNatpis,
    1: setCustomNatpis
  } = (0,external_react_.useState)({
    natpis: "The reptile house",
    checked: false
  });
  const {
    0: customBoja,
    1: setCustomBoja
  } = (0,external_react_.useState)({
    hex: "#ff0000",
    checked: false
  });
  const {
    windowSize,
    dodajUKorpu
  } = (0,ContextProvider/* useStateContext */.F)();

  function dodajClick() {
    const item = _objectSpread(_objectSpread({
      naziv: params.naziv,
      id: params.id,
      cena: params.cena,
      thumbnail: params.thumbnail,
      kolicina,
      boja: customBoja.checked ? customBoja : params.boje[bojaIndex]
    }, customNatpis.checked ? {
      natpis: customNatpis.natpis
    } : {}), {}, {
      doplate: [...(customBoja.checked ? [{
        za: "Prilagodjena boja",
        vrednost: params.doplate.boja
      }] : []), ...(customNatpis.checked ? [{
        za: "Prilagodjen natpis",
        vrednost: params.doplate.natpis
      }] : [])]
    });

    dodajUKorpu(item);
  }

  return /*#__PURE__*/jsx_runtime_.jsx(components/* Page */.T3, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        display: "flex",
        flexDirection: windowSize.width < 900 ? "column-reverse" : "row",
        gap: "2rem",
        height: "min-content",
        padding: windowSize.width <= 900 ? windowSize.width <= 500 ? "1rem" : "2rem" : ".25rem"
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("title", {
          children: [params.naziv, " | The Reptile House"]
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "description",
          content: params.opis
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        style: {
          flex: 1
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(components/* Slider */.iR, {
          slides: params.slike
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        style: {
          flex: 1.5,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "1rem"
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          style: {
            width: "100%"
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(components/* PageTitle */.V1, {
            style: {
              marginTop: 0,
              textAlign: "left"
            },
            children: params.naziv
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h3", {
            children: [params.cena, " din."]
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            children: params.opis
          }), /*#__PURE__*/jsx_runtime_.jsx(Dimenzije, {
            duzina: params.dimenzije.duzina,
            sirina: params.dimenzije.sirina,
            visina: params.dimenzije.visina
          }), /*#__PURE__*/jsx_runtime_.jsx(Dodaci, {
            dodaci: params.dodaci
          }), /*#__PURE__*/jsx_runtime_.jsx(Boje, {
            current: customBoja.checked ? -1 : bojaIndex,
            onChange: index => {
              setBojaIndex(index);
              setCustomBoja(_objectSpread(_objectSpread({}, customBoja), {}, {
                checked: false
              }));
            },
            values: params.boje
          }), /*#__PURE__*/jsx_runtime_.jsx(Cutomization, {
            bojaValue: customBoja,
            bojaChange: setCustomBoja,
            natpisValue: customNatpis,
            natpisChange: setCustomNatpis,
            doplateCene: params.doplate
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            style: {
              display: "flex",
              alignItems: windowSize.width <= 500 || windowSize.width > 900 && windowSize.width <= 1050 ? "flex-start" : "center",
              justifyContent: "space-between",
              gap: "1rem",
              width: "100%",
              flexDirection: windowSize.width <= 500 || windowSize.width > 900 && windowSize.width <= 1050 ? "column" : "row"
            },
            children: [/*#__PURE__*/jsx_runtime_.jsx(components/* Kolicina */.Ww, {
              value: kolicina,
              onChange: setKolicna
            }), /*#__PURE__*/jsx_runtime_.jsx(components/* GradientButton */.OQ, {
              onClick: dodajClick,
              children: "Dodaj u korpu"
            })]
          })]
        })
      })]
    })
  });
}

/* harmony default export */ const _id_ = (Terarijum);
async function getStaticPaths() {
  const data = await (0,terarijumi.sviTerarijumi)();
  const paths = data.map(item => ({
    params: {
      id: item.id
    }
  }));
  return {
    paths,
    fallback: "blocking"
  };
}
async function getStaticProps(context) {
  const doplateJSON = await doplate_default()();
  const terarijum = await (0,terarijumi.jedanTerarijum)(context.params.id);
  if (!terarijum) return {
    notFound: true
  };
  return {
    props: _objectSpread(_objectSpread({}, terarijum), {}, {
      doplate: doplateJSON
    }),
    revalidate: 60
  };
}

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 5974:
/***/ ((module) => {

"use strict";
module.exports = require("react-notifications");

/***/ }),

/***/ 8176:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2261:
/***/ ((module) => {

"use strict";
module.exports = require("serverless-mysql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [383,664,264], () => (__webpack_exec__(7981)));
module.exports = __webpack_exports__;

})();