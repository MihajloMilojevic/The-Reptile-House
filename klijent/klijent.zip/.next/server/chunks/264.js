exports.id = 264;
exports.ids = [264];
exports.modules = {

/***/ 1072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "$_": () => (/* reexport */ Footer_Footer),
  "OQ": () => (/* reexport */ GradientButton_GradientButton),
  "Ww": () => (/* reexport */ Kolicina_Kolicina),
  "$x": () => (/* reexport */ Kvadrat_Kvadrat),
  "x1": () => (/* reexport */ Line_Line),
  "aN": () => (/* reexport */ Loader_Loader),
  "wp": () => (/* reexport */ Navbar_Navbar),
  "T3": () => (/* reexport */ Page_Page),
  "V1": () => (/* reexport */ PageTitle_PageTitle),
  "Il": () => (/* reexport */ ProductCard_ProductCard),
  "cm": () => (/* reexport */ ProductList_ProductList),
  "pU": () => (/* reexport */ ScrollToTop_ScrollToTop),
  "eu": () => (/* reexport */ SingleProductPageContent_SingleProductPageContent),
  "iR": () => (/* reexport */ Slider_Slider)
});

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(4453);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
// EXTERNAL MODULE: ./context/ContextProvider.js + 1 modules
var ContextProvider = __webpack_require__(262);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Navbar/Navbar.jsx









const links = [{
  href: "/",
  text: "Početna"
}, {
  href: "/zivotinje",
  text: "Životinje"
}, {
  href: "/terarijumi",
  text: "Terarijumi"
}, {
  href: "/hrana",
  text: "Hrana"
}, {
  href: "/oprema",
  text: "Oprema"
}];

function Navbar() {
  const navRef = (0,external_react_.useRef)(null);
  const router = (0,router_.useRouter)();
  const {
    activeMenu,
    setActiveMenu,
    windowSize,
    korpa,
    setNavHeight
  } = (0,ContextProvider/* useStateContext */.F)();
  (0,external_react_.useEffect)(() => {
    setNavHeight(navRef.current.clientHeight);
    if (windowSize.width > 900) setActiveMenu(false);
  }, [windowSize]);
  (0,external_react_.useEffect)(() => {
    setActiveMenu(false);
  }, [router.route]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
    className: (Navbar_module_default()).navbar,
    id: "navbar",
    ref: navRef,
    children: [/*#__PURE__*/jsx_runtime_.jsx((link_default()), {
      href: "/",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Navbar_module_default()).navbar__logo,
        onClick: () => setActiveMenu(false),
        children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
          src: "/logo-no-bg.png",
          alt: "Logo",
          width: 50,
          height: 50
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          children: "The reptile house"
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `${(Navbar_module_default()).navbar__links} ${windowSize.width <= 900 ? activeMenu ? (Navbar_module_default()).active : (Navbar_module_default()).inactive : ""}`,
      children: [links.map(link => /*#__PURE__*/jsx_runtime_.jsx("div", {
        onClick: () => setActiveMenu(false),
        children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
          href: link.href,
          children: link.text
        })
      }, link.href + "-" + link.text)), /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
        href: "/korpa",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          style: {
            display: "flex",
            justfyContent: "space-between"
          },
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (Navbar_module_default()).navbar__links_korpa,
            children: [/*#__PURE__*/jsx_runtime_.jsx(bi_.BiBasket, {
              color: "black",
              size: 25
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: `gradient ${(Navbar_module_default()).navbar__links_korpa_broj}`,
              children: korpa.length
            })]
          }), windowSize.width <= 900 && /*#__PURE__*/jsx_runtime_.jsx("span", {
            style: {
              marginLeft: "1rem",
              verticalAlign: "middle"
            },
            children: "Korpa"
          })]
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Navbar_module_default()).navbar_menu,
      onClick: () => setActiveMenu(prevActiveMenu => !prevActiveMenu),
      children: activeMenu ? /*#__PURE__*/jsx_runtime_.jsx(ai_.AiOutlineClose, {}) : /*#__PURE__*/jsx_runtime_.jsx(ai_.AiOutlineMenu, {})
    })]
  });
}

/* harmony default export */ const Navbar_Navbar = (Navbar);
// EXTERNAL MODULE: ./components/Footer/Footer.module.css
var Footer_module = __webpack_require__(1877);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./components/Footer/Footer.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const Footer_links = [{
  icon: /*#__PURE__*/jsx_runtime_.jsx(bi_.BiPhone, {
    style: {
      fill: "url(#footer-gradient)"
    }
  }),
  text: /*#__PURE__*/jsx_runtime_.jsx("a", {
    href: "tel:+381695466205",
    target: "_blank",
    children: "+381695466205"
  })
}, {
  icon: /*#__PURE__*/jsx_runtime_.jsx(bi_.BiEnvelope, {
    style: {
      fill: "url(#footer-gradient)"
    }
  }),
  text: /*#__PURE__*/jsx_runtime_.jsx("a", {
    href: "mailto:thereptilehouse.info@gmail.com",
    target: "_blank",
    children: "thereptilehouse.info@gmail.com"
  })
}, {
  icon: /*#__PURE__*/jsx_runtime_.jsx(bs_.BsInstagram, {
    style: {
      fill: "url(#footer-gradient)"
    }
  }),
  text: /*#__PURE__*/jsx_runtime_.jsx("a", {
    href: "https://www.instagram.com/thereptilehouse__/",
    target: "_blank",
    children: "thereptilehouse__"
  })
}];

function Link({
  icon,
  text
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Footer_module_default()).footer__links_link,
    children: [icon, text]
  });
}

function Footer() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: (Footer_module_default()).footer,
    children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
      width: "0",
      height: "0",
      style: {
        visibility: "hidden"
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("linearGradient", {
        id: "footer-gradient",
        x1: "100%",
        y1: "100%",
        x2: "0%",
        y2: "0%",
        children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
          stopColor: "#0283E9",
          offset: "-18.13%"
        }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
          stopColor: "#FC01CA",
          offset: "120.27%"
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Footer_module_default()).footer__links,
      children: Footer_links.map((link, index) => /*#__PURE__*/jsx_runtime_.jsx(Link, _objectSpread({}, link), index))
    }), /*#__PURE__*/jsx_runtime_.jsx(Line_Line, {
      color: "black",
      width: "20%"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
      className: (Footer_module_default()).footer__copy,
      children: ["Copyright \xA9 ", new Date().getFullYear(), " The reptile house "]
    })]
  });
}

/* harmony default export */ const Footer_Footer = (Footer);
// EXTERNAL MODULE: ./components/Line/Line.module.css
var Line_module = __webpack_require__(3896);
var Line_module_default = /*#__PURE__*/__webpack_require__.n(Line_module);
;// CONCATENATED MODULE: ./components/Line/Line.jsx




function Line({
  color,
  width
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Line_module_default()).line,
    style: {
      width
    },
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Line_module_default()).line__kvadrat,
      style: {
        background: color
      }
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Line_module_default()).line__linija,
      style: {
        background: color
      }
    })]
  });
}

/* harmony default export */ const Line_Line = (Line);
;// CONCATENATED MODULE: ./components/Kvadrat/Kvadrat.jsx


function Kvadrat_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function Kvadrat_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? Kvadrat_ownKeys(Object(source), !0).forEach(function (key) { Kvadrat_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : Kvadrat_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function Kvadrat_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Kvadrat({
  style
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: Kvadrat_objectSpread({
      width: "10px",
      height: "10px",
      transform: "rotate(45deg)",
      background: "linear-gradient(238.66deg, #0283E9 -18.13%, #FC01CA 120.27%)"
    }, style)
  });
}

/* harmony default export */ const Kvadrat_Kvadrat = (Kvadrat);
// EXTERNAL MODULE: ./components/Slider/Slider.module.css
var Slider_module = __webpack_require__(3733);
var Slider_module_default = /*#__PURE__*/__webpack_require__.n(Slider_module);
;// CONCATENATED MODULE: ./components/Slider/Slider.jsx
function Slider_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function Slider_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? Slider_ownKeys(Object(source), !0).forEach(function (key) { Slider_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : Slider_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function Slider_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







function Slider({
  slides
}) {
  const {
    windowSize
  } = (0,ContextProvider/* useStateContext */.F)();
  const {
    0: currentSlide,
    1: setCurrentSlide
  } = (0,external_react_.useState)(0);
  const {
    0: imgSize,
    1: setImgSize
  } = (0,external_react_.useState)(Math.min(windowSize.width - 100, 500));
  (0,external_react_.useEffect)(() => {
    setImgSize(Math.min(windowSize.width - 100, 500));
  }, [windowSize]); // // Next/previous controls

  function next() {
    setCurrentSlide(prevCurrentSlide => (prevCurrentSlide + 1) % slides.length);
  }

  function prev() {
    setCurrentSlide(prevCurrentSlide => (prevCurrentSlide - 1 + slides.length) % slides.length);
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Slider_module_default()).slider,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Slider_module_default()).slider_container,
      children: [slides.map((image, index) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `${(Slider_module_default()).slider_slide} ${(Slider_module_default()).slider_fade}`,
          style: {
            display: currentSlide === index ? "block" : "none",
            width: imgSize,
            height: imgSize
          },
          children: /*#__PURE__*/jsx_runtime_.jsx("img", Slider_objectSpread({}, image))
        }, index);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Slider_module_default()).slider_prev,
        onClick: prev,
        children: "\u276E"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Slider_module_default()).slider_next,
        onClick: next,
        children: "\u276F"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      style: {
        textAlign: "center"
      },
      children: slides.map((_, index) => /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: `${(Slider_module_default()).slider_dot} ${currentSlide === index ? (Slider_module_default()).slider_active : ""}`,
        onClick: () => setCurrentSlide(index)
      }, index))
    })]
  });
}

/* harmony default export */ const Slider_Slider = (Slider);
// EXTERNAL MODULE: ./components/ProductCard/ProductCard.module.css
var ProductCard_module = __webpack_require__(6606);
var ProductCard_module_default = /*#__PURE__*/__webpack_require__.n(ProductCard_module);
;// CONCATENATED MODULE: ./components/ProductCard/ProductCard.jsx
function ProductCard_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function ProductCard_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ProductCard_ownKeys(Object(source), !0).forEach(function (key) { ProductCard_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ProductCard_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function ProductCard_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function ProductCard(props) {
  const {
    dodajUKorpu
  } = (0,ContextProvider/* useStateContext */.F)();

  function dodaj() {
    const item = ProductCard_objectSpread(ProductCard_objectSpread({
      naziv: props.naziv,
      id: props.id,
      cena: props.cena,
      thumbnail: props.thumbnail,
      kolicina: 1
    }, props.boje ? {
      boja: props.boje[0]
    } : {}), {}, {
      doplate: []
    });

    dodajUKorpu(item);
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (ProductCard_module_default()).product_card,
    style: props.style ?? {},
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (ProductCard_module_default()).product_card_image,
      style: {
        cursor: "pointer"
      },
      children: /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
        href: props.url,
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: props.thumbnail,
          alt: props.naziv
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (ProductCard_module_default()).product_card_content,
      children: [/*#__PURE__*/jsx_runtime_.jsx((link_default()), {
        href: props.url,
        children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
          style: {
            cursor: "pointer"
          },
          children: props.naziv
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (ProductCard_module_default()).product_card_content_row,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          children: [props.cena, "din."]
        }), /*#__PURE__*/jsx_runtime_.jsx(GradientButton_GradientButton, {
          onClick: dodaj,
          children: "Dodaj u korpu"
        })]
      })]
    })]
  });
}

/* harmony default export */ const ProductCard_ProductCard = (ProductCard);
;// CONCATENATED MODULE: ./components/ProductList/ProductList.jsx
function ProductList_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function ProductList_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ProductList_ownKeys(Object(source), !0).forEach(function (key) { ProductList_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ProductList_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function ProductList_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function ProductList({
  data,
  category
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "2rem",
      justifyContent: "center",
      alignItems: "center"
    },
    children: data.map(item => /*#__PURE__*/jsx_runtime_.jsx(ProductCard_ProductCard, ProductList_objectSpread(ProductList_objectSpread({}, item), {}, {
      url: `/${category}/${item.id}`
    }), item.id))
  });
}

/* harmony default export */ const ProductList_ProductList = (ProductList);
;// CONCATENATED MODULE: ./components/GradientButton/GradientButton.jsx
const _excluded = ["children", "onClick", "style", "className"];

function GradientButton_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function GradientButton_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? GradientButton_ownKeys(Object(source), !0).forEach(function (key) { GradientButton_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : GradientButton_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function GradientButton_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




function GradientButton(_ref) {
  let {
    children,
    onClick,
    style,
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/jsx_runtime_.jsx("button", GradientButton_objectSpread(GradientButton_objectSpread({
    onClick: onClick,
    style: GradientButton_objectSpread({
      color: "white",
      outline: "none",
      border: "none",
      borderRadius: "15px",
      padding: "1rem 1.5rem",
      fontSize: "14px",
      cursor: "pointer"
    }, style),
    className: `gradient ${className}`
  }, rest), {}, {
    children: children
  }));
}

/* harmony default export */ const GradientButton_GradientButton = (GradientButton);
// EXTERNAL MODULE: ./components/Page/Page.module.css
var Page_module = __webpack_require__(3207);
var Page_module_default = /*#__PURE__*/__webpack_require__.n(Page_module);
;// CONCATENATED MODULE: ./components/Page/Page.jsx



function Page({
  children,
  style
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (Page_module_default()).page,
    style: style,
    children: children
  });
}

/* harmony default export */ const Page_Page = (Page);
;// CONCATENATED MODULE: ./components/PageTitle/PageTitle.jsx
function PageTitle_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function PageTitle_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? PageTitle_ownKeys(Object(source), !0).forEach(function (key) { PageTitle_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : PageTitle_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function PageTitle_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function PageTitle({
  children,
  style,
  level,
  className
}) {
  return /*#__PURE__*/external_react_default().createElement(`h${level && level >= 1 && level <= 6 ? level : 1}`, {
    style: PageTitle_objectSpread({
      fontSize: 34,
      textAlign: "center",
      margin: "auto",
      marginBottom: "2rem",
      fontWeight: "bolder",
      width: "100%"
    }, style),
    className: `gradient_text ${className}`
  }, children);
}

/* harmony default export */ const PageTitle_PageTitle = (PageTitle);
// EXTERNAL MODULE: ./components/Kolicina/Kolicina.module.css
var Kolicina_module = __webpack_require__(4439);
var Kolicina_module_default = /*#__PURE__*/__webpack_require__.n(Kolicina_module);
;// CONCATENATED MODULE: ./components/Kolicina/Kolicina.jsx





function Kolicina({
  value,
  onChange,
  min,
  max
}) {
  const {
    0: kolicina,
    1: setKolicina
  } = (0,external_react_.useState)(value);
  (0,external_react_.useEffect)(() => {
    onChange(kolicina);
  }, [kolicina]);

  function povecaj() {
    setKolicina(Math.min(Math.max(kolicina + 1, min || 1), max || 100));
  }

  function smanji() {
    setKolicina(Math.max(Math.min(kolicina - 1, max || 100), min || 1));
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Kolicina_module_default()).kolicina_container,
    children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
      style: {
        fontSize: 16
      },
      children: "Koli\u010Dina: "
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Kolicina_module_default()).kolicina,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Kolicina_module_default()).kolicina_smanji,
        onClick: smanji,
        children: "-"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Kolicina_module_default()).kolicina_broj,
        children: kolicina
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Kolicina_module_default()).kolicina_povecaj,
        onClick: povecaj,
        children: "+"
      })]
    })]
  });
}

/* harmony default export */ const Kolicina_Kolicina = (Kolicina);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./components/ScrollToTop/ScrollToTop.module.css
var ScrollToTop_module = __webpack_require__(5092);
var ScrollToTop_module_default = /*#__PURE__*/__webpack_require__.n(ScrollToTop_module);
;// CONCATENATED MODULE: ./components/ScrollToTop/ScrollToTop.jsx






const ScrollToTop = () => {
  const {
    0: showTopBtn,
    1: setShowTopBtn
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 400) {
        setShowTopBtn(true);
      } else {
        setShowTopBtn(false);
      }
    });
  }, []);

  const goToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (ScrollToTop_module_default()).top_to_btm,
    children: [" ", showTopBtn && /*#__PURE__*/jsx_runtime_.jsx(fa_.FaAngleUp, {
      className: `${(ScrollToTop_module_default()).icon_position} ${(ScrollToTop_module_default()).icon_style}`,
      onClick: goToTop
    }), " "]
  });
};

/* harmony default export */ const ScrollToTop_ScrollToTop = (ScrollToTop);
;// CONCATENATED MODULE: ./components/SingleProductPageContent/SingleProductPageContent.jsx






function SingleProductPageContent(params) {
  const {
    0: kolicina,
    1: setKolicna
  } = (0,external_react_.useState)(1);
  const {
    windowSize,
    dodajUKorpu
  } = (0,ContextProvider/* useStateContext */.F)();

  function dodaj() {
    const item = {
      naziv: params.naziv,
      id: params.id,
      cena: params.cena,
      thumbnail: params.thumbnail,
      kolicina,
      doplate: []
    };
    dodajUKorpu(item);
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    style: {
      display: "flex",
      flexDirection: windowSize.width < 900 ? "column-reverse" : "row",
      gap: "2rem",
      height: "min-content",
      padding: windowSize.width >= 1200 ? "5rem" : windowSize.width >= 900 ? "2rem" : windowSize.width >= 500 ? "1rem" : "0.25rem"
    },
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      style: {
        flex: 1
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(Slider_Slider, {
        slides: params.slike
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        flex: 1.5,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        alignItems: "flex-start",
        gap: "1rem"
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        style: {
          width: "100%"
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(PageTitle_PageTitle, {
          style: {
            marginTop: 0,
            textAlign: "left"
          },
          children: params.naziv
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h3", {
          children: [params.cena, " din."]
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: params.opis
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        style: {
          display: "flex",
          alignItems: windowSize.width <= 500 || windowSize.width > 900 && windowSize.width <= 1200 ? "flex-start" : "center",
          justifyContent: "space-between",
          gap: "1rem",
          width: "100%",
          flexDirection: windowSize.width <= 500 || windowSize.width > 900 && windowSize.width <= 1200 ? "column" : "row"
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(Kolicina_Kolicina, {
          value: kolicina,
          onChange: setKolicna
        }), /*#__PURE__*/jsx_runtime_.jsx(GradientButton_GradientButton, {
          onClick: dodaj,
          children: "Dodaj u korpu"
        })]
      })]
    })]
  });
}

/* harmony default export */ const SingleProductPageContent_SingleProductPageContent = (SingleProductPageContent);
// EXTERNAL MODULE: external "react-spinners"
var external_react_spinners_ = __webpack_require__(8176);
;// CONCATENATED MODULE: ./components/Loader/Loader.jsx




function Loader({
  show
}) {
  if (!show) return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      position: "fixed",
      top: 0,
      left: 0,
      zIndex: 99999999,
      background: "rgba(200, 200, 200, 0.75)",
      width: "100vw",
      height: "100vh"
    },
    children: /*#__PURE__*/jsx_runtime_.jsx(external_react_spinners_.BounceLoader, {
      color: "#000000",
      size: 100
    })
  });
}

/* harmony default export */ const Loader_Loader = (Loader);
;// CONCATENATED MODULE: ./components/index.jsx















/***/ }),

/***/ 262:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ContextProvider),
  "F": () => (/* binding */ useStateContext)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./utils/hooks/useWindowSize.js

function useWindowSize() {
  const {
    0: windowSize,
    1: setWindowSize
  } = (0,external_react_.useState)({
    width: undefined,
    height: undefined
  });
  (0,external_react_.useEffect)(() => {
    function handleResize() {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    }

    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  return windowSize;
}
// EXTERNAL MODULE: external "react-notifications"
var external_react_notifications_ = __webpack_require__(5974);
// EXTERNAL MODULE: ./components/index.jsx + 14 modules
var components = __webpack_require__(1072);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./context/ContextProvider.js






const StateContext = /*#__PURE__*/(0,external_react_.createContext)();
function ContextProvider({
  children
}) {
  const windowSize = useWindowSize();
  const {
    0: activeMenu,
    1: setActiveMenu
  } = (0,external_react_.useState)(false);
  const {
    0: korpa,
    1: setKorpa
  } = (0,external_react_.useState)([]);
  const {
    0: ukupnaCenaKorpe,
    1: setUkupnaCenaKorpe
  } = (0,external_react_.useState)(0);
  const {
    0: loader,
    1: setLoader
  } = (0,external_react_.useState)(false);
  const {
    0: navHeight,
    1: setNavHeight
  } = (0,external_react_.useState)(0);
  (0,external_react_.useEffect)(() => {
    const required = ["id", "naziv", "cena", "kolicina", "doplate", "thumbnail"];
    const localKorpa = localStorage.getItem("korpa");
    if (!localKorpa) return;
    const jsonKorpa = JSON.parse(localKorpa);

    for (const item of jsonKorpa) {
      for (const req of required) {
        if (!item.hasOwnProperty(req)) {
          localStorage.removeItem("korpa");
          setKorpa([]);
          return;
        }
      }
    }

    setKorpa(jsonKorpa);
  }, []);
  (0,external_react_.useEffect)(() => {
    try {
      setUkupnaCenaKorpe(korpa.reduce((sum, item) => sum + item.kolicina * (item.cena + item.doplate?.reduce((prev, curr) => prev + curr.vrednost, 0)), 0));
    } catch {
      isprazniKorpu();
    }
  }, [korpa]);

  function promeniKorpu(newKorpa) {
    localStorage.setItem("korpa", JSON.stringify(newKorpa));
    setKorpa(newKorpa);
  }

  function dodajUKorpu(newItem) {
    const newKorpa = [...korpa];
    const index = newKorpa.findIndex(item => item.naziv === newItem.naziv);
    if (index < 0 || newKorpa[index]?.boja?.hex != newItem?.boja?.hex || newKorpa[index]?.natpis !== newItem?.natpis) newKorpa.push(newItem);else newKorpa[index].kolicina += newItem.kolicina;
    promeniKorpu(newKorpa);
    createNotification({
      type: notificationTypes.SUCCESS,
      message: `Uspešno ste dodali '${newItem.naziv}' u korpu.`
    });
  }

  function izbaciIzKorpe(index) {
    const item = korpa.find((_, korpaIndex) => korpaIndex === index);
    promeniKorpu(korpa.filter((_, korpaIndex) => korpaIndex !== index));
    createNotification({
      type: notificationTypes.SUCCESS,
      message: `Uspešno ste izbacili '${item.naziv}' iz korpe.`
    });
  }

  function promeniKolicinu(index, newKolicina) {
    const newKorpa = [...korpa];
    newKorpa[index].kolicina = newKolicina;
    promeniKorpu(newKorpa);
  }

  function isprazniKorpu() {
    promeniKorpu([]);
  }

  const notificationTypes = {
    INFO: "info",
    SUCCESS: "success",
    WARNING: "warning",
    ERROR: "error"
  };

  function createNotification(params) {
    const [message, title, timeout, callback, priority] = [params?.message ?? "", params?.title ?? "", params?.timeout ?? 5000, params?.callback ?? (() => {}), params?.priority ?? false];

    switch (params.type) {
      case notificationTypes.INFO:
        external_react_notifications_.NotificationManager.info(message, title, timeout, callback, priority);
        break;

      case notificationTypes.SUCCESS:
        external_react_notifications_.NotificationManager.success(message, title, timeout, callback, priority);
        break;

      case notificationTypes.WARNING:
        external_react_notifications_.NotificationManager.warning(message, title, timeout, callback, priority);
        break;

      case notificationTypes.ERROR:
        external_react_notifications_.NotificationManager.error(message, title, timeout, callback, priority);
        break;

      default:
        console.error(`${params.type} is invalid type. Try one of following: ${Object.keys(notificationTypes).join(", ")}`);
        break;
    }
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(StateContext.Provider, {
    value: {
      windowSize,
      activeMenu,
      setActiveMenu,
      korpa,
      ukupnaCenaKorpe,
      dodajUKorpu,
      izbaciIzKorpe,
      promeniKolicinu,
      isprazniKorpu,
      notificationTypes,
      createNotification,
      loader,
      setLoader,
      navHeight,
      setNavHeight
    },
    children: [children, /*#__PURE__*/jsx_runtime_.jsx(external_react_notifications_.NotificationContainer, {}), /*#__PURE__*/jsx_runtime_.jsx(components/* Loader */.aN, {
      show: loader
    })]
  });
}
function useStateContext() {
  return (0,external_react_.useContext)(StateContext);
}

/***/ }),

/***/ 1877:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__1IwEk",
	"footer__links": "Footer_footer__links__4Qw_h",
	"footer__links_link": "Footer_footer__links_link__HlLuj",
	"footer__copy": "Footer_footer__copy__uppE9"
};


/***/ }),

/***/ 4439:
/***/ ((module) => {

// Exports
module.exports = {
	"kolicina_container": "Kolicina_kolicina_container__DhtaW",
	"kolicina": "Kolicina_kolicina__u70kh",
	"kolicina_smanji": "Kolicina_kolicina_smanji__S_cpg",
	"kolicina_broj": "Kolicina_kolicina_broj__vYAbc",
	"kolicina_povecaj": "Kolicina_kolicina_povecaj__WZY7i"
};


/***/ }),

/***/ 3896:
/***/ ((module) => {

// Exports
module.exports = {
	"line": "Line_line___WM_V",
	"line__kvadrat": "Line_line__kvadrat__iNFK8",
	"line__linija": "Line_line__linija__olJpI"
};


/***/ }),

/***/ 4453:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "Navbar_navbar__OXCIL",
	"navbar__logo": "Navbar_navbar__logo__UBVq3",
	"navbar__links": "Navbar_navbar__links__sNOzd",
	"navbar_menu": "Navbar_navbar_menu__JZe_c",
	"navbar__links_korpa": "Navbar_navbar__links_korpa__iqh9E",
	"navbar__links_korpa_broj": "Navbar_navbar__links_korpa_broj__VPhs1",
	"inactive": "Navbar_inactive__br5wx",
	"active": "Navbar_active__kffsk"
};


/***/ }),

/***/ 3207:
/***/ ((module) => {

// Exports
module.exports = {
	"page": "Page_page__965tE"
};


/***/ }),

/***/ 6606:
/***/ ((module) => {

// Exports
module.exports = {
	"product_card": "ProductCard_product_card__j9IkA",
	"product_card_image": "ProductCard_product_card_image__XirGR",
	"product_card_content": "ProductCard_product_card_content__Q38_J",
	"product_card_content_row": "ProductCard_product_card_content_row__a_diI",
	"product_card_content_button": "ProductCard_product_card_content_button__55OSn"
};


/***/ }),

/***/ 5092:
/***/ ((module) => {

// Exports
module.exports = {
	"top_to_btm": "ScrollToTop_top_to_btm__b0Mao",
	"icon_position": "ScrollToTop_icon_position__9AK_9",
	"icon_style": "ScrollToTop_icon_style__ZawD6"
};


/***/ }),

/***/ 3733:
/***/ ((module) => {

// Exports
module.exports = {
	"slider": "Slider_slider__TlBhi",
	"slider_container": "Slider_slider_container__hinh_",
	"slider_slide": "Slider_slider_slide__x81VK",
	"slider_prev": "Slider_slider_prev___trM4",
	"slider_next": "Slider_slider_next__ZlKat",
	"slider_status": "Slider_slider_status__IphRs",
	"slider_dot": "Slider_slider_dot__QcZAh",
	"slider_active": "Slider_slider_active__bFTv_",
	"slider_fade": "Slider_slider_fade__qThK6",
	"fade": "Slider_fade__fIC87"
};


/***/ })

};
;